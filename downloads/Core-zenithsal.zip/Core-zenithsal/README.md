# Core

My entry for Ludum Dare 46 https://ldjam.com/users/zenithsal/

On Twitter: https://twitter.com/zenithsal


## Attributions

Music:

* Sparks (Ad Astra) by Six Umbrellas (Share-alike): https://freemusicarchive.org/music/Six_Umbrellas/Ad_Astra/10_Six_Umbrellas_-_Sparks
* Time Travel by Ketsa (CC): https://freemusicarchive.org/music/Ketsa/Above_and_Below/Time_Travel_
* Panda by Bisou (CC): https://freemusicarchive.org/music/Bisou/Musical_spaceshift/Bisou_-_Musical_Spaceship_-_09_Panda
* Launch by Ketsa (CC): https://freemusicarchive.org/music/Ketsa/Above_and_Below/Launch_1113
