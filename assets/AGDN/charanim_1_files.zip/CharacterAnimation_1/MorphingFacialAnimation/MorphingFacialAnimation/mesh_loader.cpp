/*************************************************************
 * Character Animation Article
 *
 * Title: Morphing Example
 *
 * Author: Salwan A. AlHelaly
 *
 *************************************************************/

#include "mesh_loader.h"
#include <iostream>
#include <fstream>

MeshLoader::MeshLoader(const std::wstring& meshFileName)
{
	m_strFileName = meshFileName;
	m_bFileLoaded = false;
	m_uVertexCount = 0;
	m_uFaceCount = 0;
	m_fVertices = NULL;
	m_fNormals = NULL;
	m_fMaxX = m_fMinX = m_fMaxY = m_fMinY = m_fMaxZ = m_fMinZ = 0.0f;
}

MeshLoader::~MeshLoader()
{
	unload();
}

bool MeshLoader::load()
{
	// Open file for reading in text mode
	std::ifstream meshFile(m_strFileName.c_str());
	if(!meshFile.is_open())
	{
		std::cout<<"MeshLoader could not open mesh file: "<<m_strFileName.c_str()<<std::endl;
		return false;
	}

	// Read vertex count/face count/ambient/diffuse
	meshFile>>m_uVertexCount>>m_uFaceCount;
	meshFile>>m_fAmbient[0]>>m_fAmbient[1]>>m_fAmbient[2]>>m_fAmbient[3];
	meshFile>>m_fDiffuse[0]>>m_fDiffuse[1]>>m_fDiffuse[2]>>m_fDiffuse[3];

	// Read vertices
	m_fVertices = new float [m_uVertexCount * 3];
	for(unsigned int i = 0; i < m_uVertexCount; i++)
	{
		meshFile>>m_fVertices[i * 3];
		meshFile>>m_fVertices[i * 3 + 1];
		meshFile>>m_fVertices[i * 3 + 2];

		// Bounding box data
		updateBoundingBox(&m_fVertices[i * 3]);
		updateBoundingBox(&m_fVertices[i * 3 + 1]);
		updateBoundingBox(&m_fVertices[i * 3 + 2]);
	}

	// Read normals
	m_fNormals = new float [m_uVertexCount * 3];
	for(unsigned int i = 0; i < m_uVertexCount; i++)
	{
		meshFile>>m_fNormals[i * 3];
		meshFile>>m_fNormals[i * 3 + 1];
		meshFile>>m_fNormals[i * 3 + 2];
	}

	m_bFileLoaded = true;
	return true;
}

void MeshLoader::unload()
{
	m_bFileLoaded = false;
	m_uVertexCount = 0;
	m_uFaceCount = 0;
	if(m_fVertices)
	{
		delete [] m_fVertices;
		m_fVertices = NULL;
	}
	if(m_fNormals)
	{
		delete [] m_fNormals;
		m_fNormals = NULL;
	}
	m_fMaxX = m_fMinX = m_fMaxY = m_fMinY = m_fMaxZ = m_fMinZ = 0.0f;
}

void MeshLoader::updateBoundingBox(const float* v)
{
	if(v == NULL) return;
	if(v[0] > m_fMaxX) m_fMaxX = v[0];
	if(v[0] < m_fMinX) m_fMinX = v[0];
	if(v[1] > m_fMaxY) m_fMaxY = v[1];
	if(v[1] < m_fMinY) m_fMinY = v[1];
	if(v[2] > m_fMaxZ) m_fMaxZ = v[2];
	if(v[2] < m_fMinZ) m_fMinZ = v[2];
}
