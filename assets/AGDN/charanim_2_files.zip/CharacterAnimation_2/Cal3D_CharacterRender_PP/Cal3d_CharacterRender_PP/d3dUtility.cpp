//////////////////////////////////////////////////////////////////////////////////////////////////
// 
// File: d3dUtility.cpp
//
// Desc: Provides utility functions for simplifying common tasks.
//          
//////////////////////////////////////////////////////////////////////////////////////////////////

#include "d3dUtility.h"
#include <stdexcept>

bool d3d::InitD3D(
	HINSTANCE hInstance,
	int width, int height,
	bool windowed,
	D3DDEVTYPE deviceType,
	IDirect3DDevice9** device)
{
	//
	// Create the main application window.
	//

	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = (WNDPROC)d3d::WndProc; 
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(0, IDI_APPLICATION);
	wc.hCursor       = LoadCursor(0, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = L"Direct3D9App";

	if( !RegisterClass(&wc) ) 
	{
		MessageBox(0, L"RegisterClass() - FAILED", 0, 0);
		return false;
	}
		
	HWND hwnd = 0;
	hwnd = CreateWindow(L"Direct3D9App", L"Direct3D9 Application (Coded by Salwan)", 
		WS_EX_TOPMOST,
		CW_USEDEFAULT, CW_USEDEFAULT, width, height,
		0 /*parent hwnd*/, 0 /* menu */, hInstance, 0 /*extra*/); 

	if( !hwnd )
	{
		MessageBox(0, L"CreateWindow() - FAILED", 0, 0);
		return false;
	}

	ShowWindow(hwnd, SW_SHOW);
	UpdateWindow(hwnd);

	//
	// Init D3D: 
	//

	HRESULT hr = 0;

	// Step 1: Create the IDirect3D9 object.

	IDirect3D9* d3d9 = 0;
    d3d9 = Direct3DCreate9(D3D_SDK_VERSION);

    if( !d3d9 )
	{
		MessageBox(0, L"Direct3DCreate9() - FAILED", 0, 0);
		return false;
	}

	// Step 2: Check for hardware vp.

	D3DCAPS9 caps;
	d3d9->GetDeviceCaps(D3DADAPTER_DEFAULT, deviceType, &caps);

	int vp = 0;
	if( caps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT )
		vp = D3DCREATE_HARDWARE_VERTEXPROCESSING;
	else
		vp = D3DCREATE_SOFTWARE_VERTEXPROCESSING;

	// Step 3: Fill out the D3DPRESENT_PARAMETERS structure.
 
	D3DPRESENT_PARAMETERS d3dpp;
	d3dpp.BackBufferWidth            = width;
	d3dpp.BackBufferHeight           = height;
	d3dpp.BackBufferFormat           = D3DFMT_A8R8G8B8;
	d3dpp.BackBufferCount            = 1;
	d3dpp.MultiSampleType            = D3DMULTISAMPLE_NONE;
	d3dpp.MultiSampleQuality         = 0;
	d3dpp.SwapEffect                 = D3DSWAPEFFECT_DISCARD; 
	d3dpp.hDeviceWindow              = hwnd;
	d3dpp.Windowed                   = windowed;
	d3dpp.EnableAutoDepthStencil     = true; 
	d3dpp.AutoDepthStencilFormat     = D3DFMT_D24S8;
	d3dpp.Flags                      = 0;
	d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
	d3dpp.PresentationInterval       = D3DPRESENT_INTERVAL_IMMEDIATE;

	// Step 4: Create the device.

	hr = d3d9->CreateDevice(
		D3DADAPTER_DEFAULT, // primary adapter
		deviceType,         // device type
		hwnd,               // window associated with device
		vp,                 // vertex processing
	    &d3dpp,             // present parameters
	    device);            // return created device

	if( FAILED(hr) )
	{
		// try again using a 16-bit depth buffer
		d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
		
		hr = d3d9->CreateDevice(
			D3DADAPTER_DEFAULT,
			deviceType,
			hwnd,
			vp,
			&d3dpp,
			device);

		if( FAILED(hr) )
		{
			d3d9->Release(); // done with d3d9 object
			MessageBox(0, L"CreateDevice() - FAILED", 0, 0);
			return false;
		}
	}

	d3d9->Release(); // done with d3d9 object
	
	return true;
}

int d3d::EnterMsgLoop( bool (*ptr_display)(float timeDelta) )
{
	MSG msg;
	ZeroMemory(&msg, sizeof(MSG));

	static float lastTime = (float)timeGetTime(); 

	while(msg.message != WM_QUIT)
	{
		if(PeekMessage(&msg, 0, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
        {	
			float currTime  = (float)timeGetTime();
			float timeDelta = (currTime - lastTime)*0.001f;

			ptr_display(timeDelta);

			lastTime = currTime;
        }
    }
    return msg.wParam;
}

D3DMATERIAL9 d3d::InitMtrl(D3DXCOLOR a, D3DXCOLOR d, D3DXCOLOR s, D3DXCOLOR e, float p)
{
	D3DMATERIAL9 mtrl;
	mtrl.Ambient = a;
	mtrl.Diffuse = d;
	mtrl.Specular = s;
	mtrl.Emissive = e;
	mtrl.Power = p;
	return mtrl;
}

D3DLIGHT9 d3d::InitDirectionalLight(D3DXVECTOR3* direction, D3DXCOLOR* color)
{
	D3DLIGHT9 light;
	ZeroMemory(&light, sizeof(light));
	light.Type = D3DLIGHT_DIRECTIONAL;
	light.Ambient = *color * 0.4f;
	light.Diffuse = *color;
	light.Specular = *color * 0.6f;
	light.Direction = *direction;
	return light;
}

D3DLIGHT9 d3d::InitPointLight(D3DXVECTOR3* position, D3DXCOLOR* color)
{
	D3DLIGHT9 light;
	ZeroMemory(&light, sizeof(light));
	light.Type      = D3DLIGHT_POINT;
	light.Ambient   = *color * 0.6f;
	light.Diffuse   = *color;
	light.Specular  = *color * 0.6f;
	light.Position  = *position;
	light.Range        = 1000.0f;
	light.Falloff      = 1.0f;
	light.Attenuation0 = 1.0f;
	light.Attenuation1 = 0.0f;
	light.Attenuation2 = 0.0f;
	return light;
}

D3DLIGHT9 d3d::InitSpotLight(D3DXVECTOR3* position, D3DXVECTOR3* direction, D3DXCOLOR* color)
{
	D3DLIGHT9 light;
	ZeroMemory(&light, sizeof(light));
	light.Type      = D3DLIGHT_SPOT;
	light.Ambient   = *color * 0.0f;
	light.Diffuse   = *color;
	light.Specular  = *color * 0.6f;
	light.Position  = *position;
	light.Direction = *direction;
	light.Range        = 1000.0f;
	light.Falloff      = 1.0f;
	light.Attenuation0 = 1.0f;
	light.Attenuation1 = 0.0f;
	light.Attenuation2 = 0.0f;
	light.Theta        = 0.4f;
	light.Phi          = 0.9f;
	return light;
}

WCHAR* utils::GetAngleString(WCHAR* buffer, float angle_rad)
{
	assert(buffer);
	const int angle = (int)((angle_rad * 180.0f) / 3.1415f);
	wsprintf(buffer, L"%i", angle);
	return buffer;
}

agdn::ArabicTextRenderer::ArabicTextRenderer(int maxTextWidth, int maxTextHeight, 
	float fontSize, const std::wstring& fontFamily, int fontStyle, Gdiplus::Color fontColor)
{
	mBitmap = new Gdiplus::Bitmap(maxTextWidth, maxTextHeight, PixelFormat32bppARGB);
	mBitmapData = new Gdiplus::BitmapData();
	mGraphics = Gdiplus::Graphics::FromImage(mBitmap);

	mStringFmt.SetFormatFlags(Gdiplus::StringFormatFlagsNoClip | Gdiplus::StringFormatFlagsDirectionRightToLeft);
	mStringFmt.SetAlignment(Gdiplus::StringAlignmentNear);
	mStringFmt.SetHotkeyPrefix(Gdiplus::HotkeyPrefixNone);
	mStringFmt.SetLineAlignment(Gdiplus::StringAlignmentNear);
	mStringFmt.SetTrimming(Gdiplus::StringTrimmingNone);

	mStride = (mBitmap->GetWidth() * Gdiplus::GetPixelFormatSize(mBitmap->GetPixelFormat()) / 8);
	int iBytesCount = mBitmap->GetHeight() * mStride;
	mNativeData = new char[iBytesCount];

	mBitmapData->Width = mBitmap->GetWidth();
	mBitmapData->Height = mBitmap->GetHeight();
	mBitmapData->PixelFormat = mBitmap->GetPixelFormat();
	mBitmapData->Stride = mStride;
	mBitmapData->Scan0 = mNativeData;

	// Create default font:
	mFont = new Gdiplus::Font(fontFamily.c_str(), fontSize, fontStyle, Gdiplus::UnitPoint, NULL);
	mFontColor = fontColor;
}

agdn::ArabicTextRenderer::~ArabicTextRenderer()
{
	SAFEDELETE(mFont);
	SAFEDELETEARRAY(mNativeData);
	SAFEDELETE(mBitmapData);
	SAFEDELETE(mBitmap);
}

void agdn::ArabicTextRenderer::SetFont(float emSize, const std::wstring& familyName, 
	int style, Gdiplus::Color fontColor)
{
	SAFEDELETE(mFont);
	mFont = new Gdiplus::Font(familyName.c_str(), (Gdiplus::REAL)emSize, style,
		Gdiplus::UnitPoint, NULL);
	mFontColor = fontColor;
}

void agdn::ArabicTextRenderer::RenderToTexture(const std::wstring& text, IDirect3DTexture9* d3dTexture)
{
	// Get texture dimensions
	IDirect3DSurface9* d3dSurface = NULL;
	d3dTexture->GetSurfaceLevel(0, &d3dSurface);
	D3DSURFACE_DESC textureDesc;
	d3dSurface->GetDesc(&textureDesc);
	Gdiplus::Size textureSize(textureDesc.Width, textureDesc.Height);

	// Clear bitmap
	mGraphics->Clear(Gdiplus::Color::Transparent);

	// Get bounding rect
	Gdiplus::Size textSize = MeasureStringSize(text, (float)textureSize.Width, (float)textureSize.Height);
	textSize.Width = textureSize.Width;
	textSize.Height += 2;
	printf("Measure String: %dx%d\n", textSize.Width, textSize.Height);
	if(textSize.Width > textureSize.Width || textSize.Height > textureSize.Height)
	{
		throw std::exception("agdn::ArabicTextRenderer::RenderToTexture() => Texture given is smaller than the measured text rectangle!");
	}

	// Render text
	Gdiplus::RectF textRect((float)(textureSize.Width - textSize.Width), 0.0f, (float)(textSize.Width - 1), 
		(float)(textSize.Height - 1));
	Gdiplus::SolidBrush textFill(mFontColor);
	mGraphics->DrawString(text.c_str(), -1, mFont, textRect, &mStringFmt, &textFill);

//#ifdef _DEBUG
//	// Draw the text bounding box
//	Gdiplus::Pen pen(Gdiplus::Color(255, 0, 0, 255));
//	mGraphics->DrawRectangle(&pen, textRect);
//#endif

	// Get text bitmap data
	Gdiplus::Rect lockRect(0, 0, textureSize.Width, textureSize.Height);
	Gdiplus::Status status = mBitmap->LockBits(&lockRect, 
		Gdiplus::ImageLockModeRead | Gdiplus::ImageLockModeUserInputBuf, mBitmap->GetPixelFormat(), 
		mBitmapData);
	mBitmap->UnlockBits(mBitmapData);

	// Copy text bitmap data to given d3d texture
	CopyImageToD3DSurface(d3dSurface, mNativeData, mStride, textureSize.Width, textureSize.Height);
}

Gdiplus::Size agdn::ArabicTextRenderer::MeasureStringSize(const std::wstring& text, float layoutRectWidth, 
	float layoutRectHeight)
{
	Gdiplus::RectF boundingBox;
	Gdiplus::RectF layoutRectSize(0, 0, layoutRectWidth, layoutRectHeight);
	mGraphics->MeasureString(text.c_str(), -1, mFont, layoutRectSize, &mStringFmt, &boundingBox);
	return Gdiplus::Size((INT)boundingBox.Width, (INT)boundingBox.Height);
}

void agdn::ArabicTextRenderer::CopyImageToD3DSurface(IDirect3DSurface9* d3dSurface, 
	void* sourcePixels, int stride, int width, int height)
{
	RECT srcRect;
	srcRect.left = 0;
	srcRect.top = 0;
	srcRect.right = width;
	srcRect.bottom = height;

	RECT destRect = srcRect;

	D3DXLoadSurfaceFromMemory(d3dSurface, NULL, &destRect, sourcePixels, D3DFMT_A8R8G8B8, 
		stride, NULL, &srcRect, D3DX_FILTER_NONE, 0);
}