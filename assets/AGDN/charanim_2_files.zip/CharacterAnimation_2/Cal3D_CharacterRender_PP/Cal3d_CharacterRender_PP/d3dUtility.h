//////////////////////////////////////////////////////////////////////////////////////////////////
// 
// File: d3dUtility.h
// 
// Desc: Provides utility functions for simplifying common tasks.
//          
//////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __D3DUTILITY_H__
#define __D3DUTILITY_H__

#pragma comment(lib, "d3d9.lib"	)
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "gdiplus.lib")

#include <string>
#include <d3dx9.h>
#include <gdiplus.h>
#include <math.h>
#include <assert.h>
#include "d3dfont.h"

#define SAFERELEASE(Obj)	if(Obj != NULL){Obj->Release(); Obj = NULL;}
#define SAFEDELETE(A)		if(A != NULL){delete A; A = NULL;}
#define SAFEDELETEARRAY(A)  if(A != NULL){delete [] A ;A = NULL;}

#define ShowError(MSG)		MessageBox(NULL, MSG, L"Error", MB_OK | MB_ICONERROR)
#define Key(k)				(GetAsyncKeyState(k) & 0x8000f)

#define DEGREE(rad)			((rad * 180.0f) / 3.1415f)
#define RADIAN(deg)			((deg * 3.1415f) / 180.0f)

namespace d3d
{
	bool InitD3D(
		HINSTANCE hInstance,       // [in] Application instance.
		int width, int height,     // [in] Backbuffer dimensions.
		bool windowed,             // [in] Windowed (true) or full screen (false).
		D3DDEVTYPE deviceType,     // [in] HAL or REF
		IDirect3DDevice9** device);// [out]The created device.

	int EnterMsgLoop( 
		bool (*ptr_display)(float timeDelta));

	LRESULT CALLBACK WndProc(
		HWND hwnd,
		UINT msg, 
		WPARAM wParam,
		LPARAM lParam);

	const D3DXCOLOR WHITE( D3DCOLOR_XRGB(255, 255, 255) );
	const D3DXCOLOR BLACK( D3DCOLOR_XRGB( 0, 0, 0) );
	const D3DXCOLOR RED( D3DCOLOR_XRGB(255, 0, 0) );
	const D3DXCOLOR GREEN( D3DCOLOR_XRGB( 0, 255, 0) );
	const D3DXCOLOR BLUE( D3DCOLOR_XRGB( 0, 0, 255) );
	const D3DXCOLOR YELLOW( D3DCOLOR_XRGB(255, 255, 0) );
	const D3DXCOLOR CYAN( D3DCOLOR_XRGB( 0, 255, 255) );
	const D3DXCOLOR MAGENTA( D3DCOLOR_XRGB(255, 0, 255) );

	D3DMATERIAL9 InitMtrl(D3DXCOLOR a, D3DXCOLOR d,D3DXCOLOR s, D3DXCOLOR e, float p);
	const D3DMATERIAL9 WHITE_MTRL = InitMtrl(WHITE, WHITE, WHITE, BLACK, 8.0f);
	const D3DMATERIAL9 RED_MTRL = InitMtrl(RED, RED, RED, BLACK, 8.0f);
	const D3DMATERIAL9 GREEN_MTRL = InitMtrl(GREEN, GREEN, GREEN, BLACK, 8.0f);
	const D3DMATERIAL9 BLUE_MTRL = InitMtrl(BLUE, BLUE, BLUE, BLACK, 8.0f);
	const D3DMATERIAL9 YELLOW_MTRL = InitMtrl(YELLOW, YELLOW, YELLOW, BLACK, 8.0f);
	
	D3DLIGHT9 InitDirectionalLight(D3DXVECTOR3* direction, D3DXCOLOR* color);
	D3DLIGHT9 InitPointLight(D3DXVECTOR3* position, D3DXCOLOR* color);
	D3DLIGHT9 InitSpotLight(D3DXVECTOR3* position, D3DXVECTOR3* direction, D3DXCOLOR* color);

}

namespace utils
{
	WCHAR* GetAngleString(WCHAR* buffer, float angle_rad);
}

namespace agdn
{
	// ��� ����� ����� �� ���� �� ��� ����� ���� ���� ������ ��� ���� ������ ��� ��
	// �����: ���� �������
	// ������ ������� ������ �������
	// http://www.agdn-online.com
	// ���� ��� �������:
	// http://www.agdn-online.com/communities.aspx?view=posts&threadid=544
	class ArabicTextRenderer
	{
	public:
		ArabicTextRenderer(int maxTextWidth, int maxTextHeight, float fontSize = 12, 
			const std::wstring& fontFamily = L"Arabic Transparent", int fontStyle = Gdiplus::FontStyleRegular, 
			Gdiplus::Color fontColor = Gdiplus::Color(255, 255, 255, 255));
		virtual ~ArabicTextRenderer();

		void RenderToTexture(const std::wstring& text, IDirect3DTexture9* d3dTexture);
		void SetFont(float emSize, const std::wstring& familyName = L"Arabic Transparent", 
			int style = Gdiplus::FontStyleRegular,  
			Gdiplus::Color fontColor = Gdiplus::Color(255, 255, 255, 255));
		Gdiplus::Size MeasureStringSize(const std::wstring& text, float layoutRectWidth, 
			float layoutRectHeight);

	private:
		void CopyImageToD3DSurface(IDirect3DSurface9* d3dSurface, void* sourcePixels, 
			int stride, int width, int height);

		Gdiplus::Bitmap*		mBitmap;
		Gdiplus::BitmapData*	mBitmapData;
		Gdiplus::Graphics*		mGraphics;
		Gdiplus::StringFormat	mStringFmt;
		Gdiplus::Font*			mFont;
		Gdiplus::Color			mFontColor;
		void*					mNativeData;
		int						mStride;
	};
}

#endif