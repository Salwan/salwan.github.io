/*************************************************************
 * Character Animation Article
 *
 * Title: Functions used to create simple geometry.
 *
 * Author: Salwan A. AlHelaly
 *
 *************************************************************/

#include "geometry.h"
using namespace geometry;


//
// D3DGeometryContainer Implementation
//
D3DGeometryContainer::D3DGeometryContainer(IDirect3DDevice9* Device) : mDevice(Device),
	m_vPosition(D3DXVECTOR3(0.0f, 0.0f, 0.0f)), m_vRotation(D3DXVECTOR3(0.0f, 0.0f, 0.0f)),
	m_bManualTransformation(false), m_uVertexCount(0), m_uIndexCount(0)
{
	assert(mDevice);
	
	HRESULT hr;

	// Alot of storage to be able to hold a large number of geometric information
	hr = mDevice->CreateVertexBuffer(30000 * sizeof(Vertex),
		D3DUSAGE_WRITEONLY, Vertex::FVF, D3DPOOL_DEFAULT,
		&mVB, 0);
	if(FAILED(hr)) throw std::wstring(L"D3DGeometryContainer: Could not create vertex buffer");

#ifdef GEOMETRY_USE_16_BIT_INDICES
	hr = mDevice->CreateIndexBuffer(30000 * sizeof(GeoIndex),
		D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT,
		&mIB, 0);
#else
	hr = mDevice->CreateIndexBuffer(30000 * sizeof(GeoIndex),
		D3DUSAGE_WRITEONLY, D3DFMT_INDEX32, D3DPOOL_DEFAULT,
		&mIB, 0);
#endif
	if(FAILED(hr)) throw std::wstring(L"D3DGeometryContainer: Could not create index buffer");
}

D3DGeometryContainer::~D3DGeometryContainer()
{
	SAFERELEASE(mVB);
	SAFERELEASE(mIB);
	GCMapIterator i;
	for(i = mGCMap.begin(); i != mGCMap.end(); ++i)
	{
		if(i->second.pTexture)
		{
			SAFERELEASE(i->second.pTexture);
		}
	}
}

void D3DGeometryContainer::add(unsigned int id, GeoData& data)
{
	if(!hasId(id))
	{
		HRESULT hr;
		Vertex* vs;
		GeoIndex* is;
		GeoDesc gd;
		gd.uVertexCount = data.uVertexCount;
		gd.uFaceCount = data.uFaceCount;
		gd.vbIndex = m_uVertexCount;
		gd.ibIndex = m_uIndexCount;

		// Write data to vertex/index buffers
		hr = mVB->Lock(m_uVertexCount * sizeof(Vertex), gd.uVertexCount * sizeof(Vertex),
			(void**)&vs, 0);
		if(FAILED(hr)) throw std::wstring(L"D3DGeometryContainer: Could not lock vertex buffer for writing");
		memcpy(vs, data.pVertices, data.uVertexCount * sizeof(Vertex));
		mVB->Unlock();

		hr = mIB->Lock(m_uIndexCount * sizeof(GeoIndex), gd.uFaceCount * 3 * sizeof(GeoIndex),
			(void**)&is, 0);
		if(FAILED(hr)) throw std::wstring(L"D3DGeometryContainer: Could not lock index buffer for writing");
		memcpy(is, data.pIndices, data.uFaceCount * 3 * sizeof(GeoIndex));
		mIB->Unlock();

		// Update vertex/index count
		m_uVertexCount += data.uVertexCount;
		m_uIndexCount += data.uFaceCount * 3;

		// We don't need vertex/index data memory anymore
		data.release();
		
		mGCMap[id] = gd;
	}
}

void D3DGeometryContainer::giveTextureTo(unsigned int id, const std::wstring& textureFile)
{
	GCMapIterator it = findId(id);
	if(it != mGCMap.end())
	{
		HRESULT hr;
		LPDIRECT3DTEXTURE9 texture = NULL;
		hr = D3DXCreateTextureFromFile(mDevice, textureFile.c_str(), &texture);
		if(SUCCEEDED(hr))
		{
			it->second.pTexture = texture;
		}
	}
}

void D3DGeometryContainer::setPosition(const D3DXVECTOR3& position)
{
	m_vPosition = position;
	m_bManualTransformation = false;
}

void D3DGeometryContainer::setRotation(const D3DXVECTOR3& rotation)
{
	m_vRotation = rotation;
	m_bManualTransformation = false;
}

void D3DGeometryContainer::setManualTransformationMode(bool manual)
{
	m_bManualTransformation = manual;
}

// Sets the stream, fvf, vertex buffer, index buffer, transformation, and draws triangle lists
void D3DGeometryContainer::draw(unsigned int id)
{
	if(!hasId(id))
	{
		return;
	}

	if(!m_bManualTransformation)
	{
		// Rotate then Translate
		D3DXMATRIX mat1, mat2;
		D3DXMatrixRotationYawPitchRoll(&mat1, m_vRotation.y, m_vRotation.x, m_vRotation.z);
		D3DXMatrixTranslation(&mat2, m_vPosition.x, m_vPosition.y, m_vPosition.z);
		mat1 = mat1 * mat2;
		mDevice->SetTransform(D3DTS_WORLD, &mat1);
	}

	// Get data
	GeoDesc gd = mGCMap[id];

	// Set direct3d stuff
	if(gd.pTexture)
	{
		mDevice->SetTexture(0, gd.pTexture);
	}
	mDevice->SetStreamSource(0, mVB, 0, sizeof(Vertex));
	mDevice->SetFVF(Vertex::FVF);
	mDevice->SetIndices(mIB);
	mDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, gd.vbIndex, 0, gd.uVertexCount, gd.ibIndex, gd.uFaceCount);
}

// �����:
// ����� ������ ��� ����� ����� ������ �� ��� ������� ����� ����� �����
// �� �� ���� �� ���� ������ ���� ������ ��������� ���� ��� ��� �� ������� ��� ��������

const DWORD Vertex::FVF = (D3DFVF_XYZ | D3DFVF_NORMAL |D3DFVF_TEX1);

GeoData geometry::createQuad(float width, float length, float tiles_u, float tiles_v)
{
	Vertex* vs = new Vertex [4];
	GeoIndex* is = new GeoIndex [6];

	// This is called 'being lazy' :P
	const float x = width / 2.0f;
	const float y = 0.0f;
	const float z = length / 2.0f;
	const float u = tiles_u;
	const float v = tiles_v;
	const D3DXVECTOR3 normal = D3DXVECTOR3(0.0f, 1.0f, 0.0f);

	vs[0] = Vertex(D3DXVECTOR3(-x, y, z), normal, D3DXVECTOR2(0.0f, 0.0f));
	vs[1] = Vertex(D3DXVECTOR3(x, y, z), normal, D3DXVECTOR2(u, 0.0f));
	vs[2] = Vertex(D3DXVECTOR3(-x, y, -z), normal, D3DXVECTOR2(0.0f, v));
	vs[3] = Vertex(D3DXVECTOR3(x, y, -z), normal, D3DXVECTOR2(u, v));

	is[0] = 0; is[1] = 1; is[2] = 2;
	is[3] = 1; is[4] = 3; is[5] = 2;

	GeoData data;
	data.uFaceCount = 2;
	data.uVertexCount = 4;
	data.pVertices = vs;
	data.pIndices = is;

	return data;
}

GeoData geometry::createPlane(float width, float length, int width_segment_count, int height_segment_count, 
		float tiles_per_quad_u, float tiles_per_quad_v)
{
	int vcount = (width_segment_count + 1) * (height_segment_count + 1);
	int qcount = (width_segment_count * height_segment_count);
	int icount = qcount * 2 * 3;
	Vertex* vs = new Vertex [vcount];
	GeoIndex* is = new GeoIndex [icount];

	// first the vertices
	const D3DXVECTOR3 normal = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	int i, j;
	float vx, vz;
	const float xo = -width / 2.0f;
	const float zo = -length / 2.0f;
	const float xs = width / (float)width_segment_count;	// segment width
	const float zs = length / (float)height_segment_count;	// segment length
	const float u = tiles_per_quad_u;
	const float v = tiles_per_quad_v;

	for(j = 0; j < height_segment_count + 1; j++)
		for(i = 0; i < width_segment_count + 1; i++)
		{
			vx = (i * xs) + xo;
			vz = (j * -zs) - zo;
			vs[(j * (width_segment_count+1)) + i] = Vertex(D3DXVECTOR3(vx, 0.0f, vz), normal, D3DXVECTOR2(i * u, j * u));
		}

	// then the indices
	int c = 0;
	for(j = 0; j < height_segment_count; j++)
		for(i = 0; i < width_segment_count; i++)
		{
			int a = (j * (width_segment_count + 1)) + i;

			is[c] = a;
			is[c+1] = a + 1;
			is[c+2] = a + (width_segment_count + 1);

			is[c+3] = a + 1;
			is[c+4] = a + (width_segment_count + 2);
			is[c+5] = a + (width_segment_count + 1);

			c += 6;
		}

	GeoData data;
	data.uFaceCount = (unsigned int)qcount * 2;
	data.uVertexCount = (unsigned int)vcount;
	data.pVertices = vs;
	data.pIndices = is;

	return data;
}

GeoData geometry::createBox(float width, float length, float height, float tiles_per_face_u, float tiles_per_face_v)
{
	int fcount = 12;
	int icount = fcount * 3;
	int vcount = 24;

	Vertex* vs = new Vertex [vcount];
	GeoIndex* is = new GeoIndex [icount];

	// No tricks here, just code monkeying...
	D3DXVECTOR3 normal;
	float u = tiles_per_face_u;
	float v = tiles_per_face_v;
	float hx = width / 2;
	float hy = height / 2;
	float hz = length / 2;
	int c = 0;

	// Front face
	normal = D3DXVECTOR3(0.0f, 0.0f, -1.0f);
	vs[0] = Vertex(	D3DXVECTOR3(-hx, hy, -hz),	normal, D3DXVECTOR2(0.0f, 0.0f));
	vs[1] = Vertex(	D3DXVECTOR3(hx, hy, -hz),	normal, D3DXVECTOR2(u, 0.0f));
	vs[2] = Vertex(	D3DXVECTOR3(-hx, -hy, -hz),	normal, D3DXVECTOR2(0.0f, v));
	vs[3] = Vertex(	D3DXVECTOR3(hx, -hy, -hz),	normal, D3DXVECTOR2(u, v));
	
	is[c++] = 0; is[c++] = 1; is[c++] = 2;
	is[c++] = 1; is[c++] = 3; is[c++] = 2;

	// Back face
	normal = D3DXVECTOR3(0.0f, 0.0f, 1.0f);
	vs[4] = Vertex(	D3DXVECTOR3(hx, hy, hz),	normal, D3DXVECTOR2(0.0f, 0.0f));
	vs[5] = Vertex(	D3DXVECTOR3(-hx, hy, hz),	normal, D3DXVECTOR2(u, 0.0f));
	vs[6] = Vertex(	D3DXVECTOR3(hx, -hy, hz),	normal, D3DXVECTOR2(0.0f, v));
	vs[7] = Vertex(	D3DXVECTOR3(-hx, -hy, hz),	normal, D3DXVECTOR2(u, v));

	is[c++] = 4; is[c++] = 5; is[c++] = 6;
	is[c++] = 5; is[c++] = 7; is[c++] = 6;

	// Right face
	normal = D3DXVECTOR3(1.0f, 0.0f, 0.0f);
	vs[8] = Vertex(	D3DXVECTOR3(hx, hy, -hz),	normal, D3DXVECTOR2(0.0f, 0.0f));
	vs[9] = Vertex(	D3DXVECTOR3(hx, hy, hz),	normal, D3DXVECTOR2(u, 0.0f));
	vs[10]= Vertex(	D3DXVECTOR3(hx, -hy, -hz),	normal, D3DXVECTOR2(0.0f, v));
	vs[11]= Vertex(	D3DXVECTOR3(hx, -hy, hz),	normal, D3DXVECTOR2(u, v));

	is[c++] = 8; is[c++] = 9; is[c++] = 10;
	is[c++] = 9; is[c++] = 11; is[c++] = 10;

	// Left face
	normal = D3DXVECTOR3(-1.0f, 0.0f, 0.0f);
	vs[12]= Vertex(	D3DXVECTOR3(-hx, hy, hz),	normal, D3DXVECTOR2(0.0f, 0.0f));
	vs[13]= Vertex(	D3DXVECTOR3(-hx, hy, -hz),	normal, D3DXVECTOR2(u, 0.0f));
	vs[14]= Vertex(	D3DXVECTOR3(-hx, -hy, hz),	normal, D3DXVECTOR2(0.0f, v));
	vs[15]= Vertex(	D3DXVECTOR3(-hx, -hy, -hz),	normal, D3DXVECTOR2(u, v));

	is[c++] = 12; is[c++] = 13; is[c++] = 14;
	is[c++] = 13; is[c++] = 15; is[c++] = 14;

	// Top face
	normal = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	vs[16]= Vertex(	D3DXVECTOR3(-hx, hy, hz),	normal, D3DXVECTOR2(0.0f, 0.0f));
	vs[17]= Vertex(	D3DXVECTOR3(hx, hy, hz),	normal, D3DXVECTOR2(u, 0.0f));
	vs[18]= Vertex(	D3DXVECTOR3(-hx, hy, -hz),	normal, D3DXVECTOR2(0.0f, v));
	vs[19]= Vertex(	D3DXVECTOR3(hx, hy, -hz),	normal, D3DXVECTOR2(u, v));

	is[c++] = 16; is[c++] = 17; is[c++] = 18;
	is[c++] = 17; is[c++] = 19; is[c++] = 18;

	// Bottom face
	normal = D3DXVECTOR3(0.0f, -1.0f, 0.0f);
	vs[20]= Vertex(	D3DXVECTOR3(-hx, -hy, -hz),	normal, D3DXVECTOR2(0.0f, 0.0f));
	vs[21]= Vertex(	D3DXVECTOR3(hx, -hy, -hz),	normal, D3DXVECTOR2(u, 0.0f));
	vs[22]= Vertex(	D3DXVECTOR3(-hx, -hy, hz),	normal, D3DXVECTOR2(0.0f, v));
	vs[23]= Vertex(	D3DXVECTOR3(hx, -hy, hz),	normal, D3DXVECTOR2(u, v));

	is[c++] = 20; is[c++] = 21; is[c++] = 22;
	is[c++] = 21; is[c++] = 23; is[c++] = 22;

	GeoData data;
	data.uFaceCount = (unsigned int)fcount;
	data.uVertexCount = (unsigned int)vcount;
	data.pVertices = vs;
	data.pIndices = is;

	return data;
}