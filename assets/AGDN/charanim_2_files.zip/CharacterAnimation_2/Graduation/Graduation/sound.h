////////////////////////////////////////////////////////////////////////
// Project: SpaceHawk
// Author:	Salwan A. AlHelaly
// Desc:	Audiere sound system wrapper
////////////////////////////////////////////////////////////////////////
// Notes:
////////////////////////////////////////////////////////////////////////
#ifndef __SOUND_H__
#define __SOUND_H__

// Pre-definitions

// Includes
#include <map>
#include "audiere/audiere.h"
#pragma comment(lib, "audiere/audiere.lib")

using namespace audiere;

// Definitions

// Enums

// Structures

// Classes
//-----------------------------------------------------------------------
// Class: CSound
// Desc: Represents a sound effect, or music. Sound effects can be two
//	types, 2D and 3D. 3D will need a 'listener' to be updated per
//	frame and a sound node to keep track of the sources position in space, 
//	volume will be set based on the distance. Possible addition
//	of right/left channel effect.
//	2D sound type is just a normal sound.
//	Sound affectors can be added per-sound, possible affectors include:
//	* Pitch 
//	More to be added.
//=======================================================================
class CSound
{
public:
	// Constructor/Destructor
	CSound();
	~CSound();

	// Methods
	bool Init();
	void Cleanup();
	void Update( float timeDelta );
	
	// Takes the sound effect file (should be in wav) and returns an index for it
	unsigned int addSoundEffect( const char* filename, bool isMultiple, unsigned int id = 0 );
	// Takes the music file (should be in ogg) and returns an index for it
	unsigned int addMusic( const char* filename, unsigned int id = 0, bool streaming = true );
	// Removes a sound effect
	void removeSoundEffect( unsigned int id );
	// Removes a music item
	void removeMusic( unsigned int id );

	// Access Methods
	void playSound( unsigned int id );
	void stopSound( unsigned int id );
	void setSoundVolume( unsigned int id, float volume );
	float getSoundVolume( unsigned int id );
	void setSoundPan( unsigned int id, float pan );
	float getSoundPan( unsigned int id );
	void setSoundPitchShift( unsigned int id, float shift );
	float getSoundPitchShift( unsigned int id );/**/
	
	void playMusic( unsigned int id );
	void stopMusic( unsigned int id );
	bool isMusicPlaying( unsigned int id );
	void resetMusic( unsigned int id );
	void setMusicRepeat( unsigned int id, bool repeat );
	bool getMusicRepeat( unsigned int id );
	void setMusicVolume( unsigned int id, float volume );
	float getMusicVolume( unsigned int id );
	void setMusicPan( unsigned int id, float pan );
	float getMusicPan( unsigned int id );
	void setMusicPitchShift( unsigned int id, float shift );
	float getMusicPitchShift( unsigned int id );
	bool isMusicSeekable( unsigned int id );
	int getMusicLength( unsigned int id );
	void setMusicPosition( unsigned int id, int position );
	int getMusicPosition( unsigned int id );/**/

private:
	// Methods
	bool _soundEffectExists( unsigned int id );
	bool _musicExists( unsigned int id );

	// Objects
	AudioDevicePtr	audio;
	std::map< unsigned int, SoundEffectPtr >				SoundEffectsMap;
	std::map< unsigned int, SoundEffectPtr >::iterator	SoundEffectsMap_i;
	std::map< unsigned int, OutputStreamPtr >			MusicMap;
	std::map< unsigned int, OutputStreamPtr >::iterator	MusicMap_i;

	// Parameters
	unsigned int				SoundEffectsIndex;
	unsigned int				MusicIndex;

	// States
	bool			isInitialized;
};

//-----------------------------------------------------------------------
// Class:
// Desc:
//
//=======================================================================

#endif
//--------------------------------------------------------------------END