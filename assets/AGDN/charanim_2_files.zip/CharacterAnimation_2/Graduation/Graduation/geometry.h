/*************************************************************
 * Character Animation Article
 *
 * Title: Functions used to create simple geometry.
 *
 * Author: Salwan A. AlHelaly
 *
 *************************************************************/

#ifndef __GEOMETRY_H__
#define __GEOMETRY_H__

#include "d3dUtility.h"
#include <map>

#ifdef GEOMETRY_USE_16_BIT_INDICES
typedef unsigned short GeoIndex;
#else
typedef unsigned int GeoIndex;
#endif

namespace geometry
{
	struct Rectf
	{
		Rectf() { }
		Rectf(float _left, float _top, float _right, float _bottom)
		{
			left = _left; 
			top = _top;
			right = _right;
			bottom = _bottom;
		}
		inline bool collisionXZ(const D3DXVECTOR3& pos)
		{
			if(pos.x > right || pos.x < left)
				return false;
			if(pos.z < bottom || pos.z > top)
				return false;
			return true;
		}
		float left, top, right, bottom;
	};

	struct Vertex
	{
		Vertex()
		{
			vPosition.x = 0.0f; vPosition.y = 0.0f; vPosition.z = 0.0f;
			vNormal.x = 0.0f; vNormal.y = 0.0f; vNormal.z = 0.0f;
			vTexCoord.x = 0.0f; vTexCoord.y = 0.0f;
		}

		Vertex(const D3DXVECTOR3& position,
			const D3DXVECTOR3& normal,
			const D3DXVECTOR2& texcoord)
		{
			vPosition = position;
			vNormal = normal;
			vTexCoord = texcoord;
		}

		D3DXVECTOR3		vPosition;
		D3DXVECTOR3		vNormal;
		D3DXVECTOR2		vTexCoord;
		static const DWORD	FVF;
	};

	struct GeoData
	{
		GeoData() : pVertices(NULL),
			pIndices(NULL), uVertexCount(0),
			uFaceCount(0)
		{
		}
		void release()
		{
			delete pVertices;
			pVertices = NULL;
			delete pIndices;
			pIndices = NULL;
		}
		Vertex*					pVertices;
		GeoIndex*				pIndices;
		unsigned int			uVertexCount;
		unsigned int			uFaceCount;
	};

	GeoData createQuad(float width, float length, float tiles_u = 1.0f, float tiles_v = 1.0f);
	GeoData createPlane(float width, float length, int width_segment_count, int height_segment_count, 
		float tiles_per_quad_u = 1.0f, float tiles_per_quad_v = 1.0f);
	GeoData createBox(float width, float length, float height, 
		float tiles_per_face_u = 1.0f, float tiles_per_face_v = 1.0f);
	
	// This object manages and draws GeoData produced by geometry functions.
	class D3DGeometryContainer
	{
	public:
		D3DGeometryContainer(IDirect3DDevice9* Device);
		virtual ~D3DGeometryContainer();

		void add(unsigned int id, GeoData& data);
		void giveTextureTo(unsigned int id, const std::wstring& textureFile);
		void setPosition(const D3DXVECTOR3& position);
		void setRotation(const D3DXVECTOR3& rotation);
		void setManualTransformationMode(bool manual);
		void draw(unsigned int id);

	private:
		struct GeoDesc
		{
			GeoDesc() : vbIndex(0), ibIndex(0), uVertexCount(0), uFaceCount(0), pTexture(NULL)
			{ }
			unsigned int vbIndex;
			unsigned int ibIndex;
			unsigned int uVertexCount;
			unsigned int uFaceCount;
			LPDIRECT3DTEXTURE9	pTexture;
		};

		std::map<unsigned int, GeoDesc>				mGCMap;
		typedef std::map<unsigned int, GeoDesc>::iterator GCMapIterator;

		bool hasId(unsigned int id)
		{
			if(findId(id) != mGCMap.end())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		
		GCMapIterator findId(unsigned int id)
		{
			return mGCMap.find(id);
		}

		LPDIRECT3DDEVICE9							mDevice;
		LPDIRECT3DVERTEXBUFFER9						mVB;
		LPDIRECT3DINDEXBUFFER9						mIB;

		unsigned int								m_uVertexCount;
		unsigned int								m_uIndexCount;

		D3DXVECTOR3									m_vPosition;
		D3DXVECTOR3									m_vRotation;

		bool										m_bManualTransformation;
	};

};

#endif