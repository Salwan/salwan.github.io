////////////////////////////////////////////////////////////////////////
// Project: SpaceHawk
// Author: Salwan A. AlHelaly
// Desc:
////////////////////////////////////////////////////////////////////////
// Notes:
////////////////////////////////////////////////////////////////////////

// Pre-definitions

// Includes
#include "sound.h"

// Definitions

// Implementations

//--------------------------------------------------------------------
// Method: CSound()
// Desc: Constructor
//
CSound::CSound()
{
	audio = 0;
	isInitialized = false;
	SoundEffectsIndex = 0;
	MusicIndex = 0;
}
//====================================================================

//--------------------------------------------------------------------
// Method: ~CSound()
// Desc: Destructor
//
CSound::~CSound()
{
}
//====================================================================

//--------------------------------------------------------------------
// Method: Init()
// Desc: Initializes the sound system
//
bool CSound::Init()
{
	audio = ::OpenDevice();
	if( !audio )
	{
		// Trying to create a "null" audio device:
		audio = ::OpenDevice( "null" );
		if( !audio )
		{
			//throw std::wstring(L"Could not create sound system");
			return false;
		}
	}
	// Success!
	isInitialized = true;
	return true;
}
//====================================================================

//--------------------------------------------------------------------
// Method: Cleanup()
// Desc: Cleans up allocated objects
//
void CSound::Cleanup()
{
	if( !SoundEffectsMap.empty() )
	{
		for( SoundEffectsMap_i = SoundEffectsMap.begin();
			SoundEffectsMap_i != SoundEffectsMap.end();
			SoundEffectsMap_i++ )
		{
			(*SoundEffectsMap_i).second->stop();
			(*SoundEffectsMap_i).second = 0;	
		}
		SoundEffectsMap.clear();
	}
	if( !MusicMap.empty() )
	{
		for( MusicMap_i = MusicMap.begin();
			MusicMap_i != MusicMap.end();
			MusicMap_i++ )
		{
			(*MusicMap_i).second->stop();
			(*MusicMap_i).second = 0;
		}
		MusicMap.clear();
	}
	SoundEffectsIndex = 0;
	MusicIndex = 0;
	audio = 0;
	isInitialized = false;
}
//====================================================================

//--------------------------------------------------------------------
// Method: Update()
// Desc: Updates the sound system.
//
void CSound::Update( float timeDelta )
{
	if( isInitialized )
	{
	}
}
//====================================================================

//--------------------------------------------------------------------
// Method: addSoundEffect()
// Desc: Adds a new sound effect, it does not do any checking of
//	whether the sound is already loaded or not for flexibility reasons
//	You can pass a specific id, and if it doesnt exist the new sound
//	will be created there, if it does, it will throw an exception.
//
unsigned int CSound::addSoundEffect( const char* filename, bool isMultiple = true, unsigned int id )
{
	if( isInitialized )
	{
		SoundEffectType t = isMultiple? MULTIPLE : SINGLE;
		SoundEffectPtr sfx = OpenSoundEffect( audio, filename, t );
		if( !sfx )
		{
			return 0;
		}
		if( id == 0 )
		{
			do
			{
				SoundEffectsIndex++;
			} while( _soundEffectExists( SoundEffectsIndex ) );
			SoundEffectsMap.insert( std::make_pair( SoundEffectsIndex, sfx ) );
			return SoundEffectsIndex;
		}
		else
		{
			if( !_soundEffectExists( id ) )
			{
				SoundEffectsMap.insert( std::make_pair( id, sfx ) );
			}
			return id;
		}
	}
	return 0;
}
//====================================================================

//--------------------------------------------------------------------
// Method: addMusic()
// Desc: Adds a new music file, does not do any checking of whether a
//	similar music exists or not for flexibility reasons.
//	this will always be set to stream.
//	You can pass a specific id, and if it doesnt exist the new sound
//	will be created there, if it does, it will throw an exception.
//
unsigned int CSound::addMusic( const char *filename, unsigned int id, bool streaming )
{
	if( isInitialized )
	{
		OutputStreamPtr strm = OpenSound( audio, filename, streaming );
		if( !strm )
		{
			return 0;
		}
		if( id == 0 )
		{
			do
			{
				MusicIndex++;
			} while( _musicExists( MusicIndex ) );
			MusicMap.insert( std::make_pair( MusicIndex, strm ) );
			return MusicIndex;
		}
		else
		{
			if( !_musicExists( id ) )
			{
				MusicMap.insert( std::make_pair( id, strm ) );
			}
			return id;
		}
	}
	return 0;
}
//====================================================================

//--------------------------------------------------------------------
// Method: removeSoundEffect()
// Desc: Stops and removes the specified sound effect if it exists.
//
void CSound::removeSoundEffect( unsigned int id )
{
	if( _soundEffectExists( id ) )
	{
		if( isInitialized )
			stopSound( id );
		SoundEffectsMap[id] = 0;
		SoundEffectsMap.erase( id );
	}
}
//====================================================================

//--------------------------------------------------------------------
// Method: removeMusic()
// Desc: Stops and removes the specified music if it exists.
//
void CSound::removeMusic( unsigned int id )
{
	if( _musicExists( id ) )
	{
		if( isInitialized )
			stopMusic( id );
		MusicMap[id] = 0;
		MusicMap.erase( id );
	}
}
//====================================================================

//--------------------------------------------------------------------
// Method: _soundEffectExists()
// Desc: returns whether a sound effect with the given id exists or not.
//	throws exception EXECUTE_FAULT if the id = 0
//
bool CSound::_soundEffectExists( unsigned int id )
{
	if( SoundEffectsMap.empty() )
		return false;
	if( SoundEffectsMap.find( id ) == SoundEffectsMap.end() )
		return false;
	return true;
}
//====================================================================

//--------------------------------------------------------------------
// Method: _musicExists()
// Desc: returns whether a music with the given id exists or not.
//	throws exception EXECUTE_FAULT if the id = 0
//
bool CSound::_musicExists( unsigned int id )
{
	if( MusicMap.empty() )
		return false;
	if( MusicMap.find( id ) == MusicMap.end() )
		return false;
	return true;
}
//====================================================================

//--------------------------------------------------------------------
// Method: playSound()
// Desc: Starts playing the specified sound.
//
void CSound::playSound( unsigned int id )
{
	if( _soundEffectExists( id ) )
		SoundEffectsMap[id]->play();
}
//====================================================================

//--------------------------------------------------------------------
// Method: stopSound( unsigned int id )
// Desc: Stops playing the specified sound.
//
void CSound::stopSound( unsigned int id )
{
	if( _soundEffectExists( id ) )
		SoundEffectsMap[id]->stop();
}
//====================================================================

//--------------------------------------------------------------------
// Method: setSoundVolume()
// Desc: Sets the volume of the sound to a value from 0.0 to 1.0
//
void CSound::setSoundVolume( unsigned int id, float volume )
{
	if( _soundEffectExists( id ) )
		SoundEffectsMap[id]->setVolume( volume );
}
//====================================================================

//--------------------------------------------------------------------
// Method: getSoundVolume()
// Desc: Returns the current sound volume
//
float CSound::getSoundVolume( unsigned int id )
{
	if( _soundEffectExists( id ) )
		return SoundEffectsMap[id]->getVolume();
	return 0.0f;
}
//====================================================================

//--------------------------------------------------------------------
// Method: setSoundPan()
// Desc: Sets the sound pan. left: -1.0, center: 0.0, right: 1.0
//
void CSound::setSoundPan( unsigned int id, float pan )
{
	if( _soundEffectExists( id ) )
		SoundEffectsMap[id]->setPan( pan );
}
//====================================================================

//--------------------------------------------------------------------
// Method: getSoundPan()
// Desc: Returns the current pan. left: -1.0, center: 0.0, right: 1.0
//
float CSound::getSoundPan( unsigned int id )
{
	if( _soundEffectExists( id ) )
		return SoundEffectsMap[id]->getPan();
	return 0.0;
}
//====================================================================

//--------------------------------------------------------------------
// Method: setSoundPitchShift()
// Desc: Sets the sound pitch. range: 0.5 - 2.0, default: 1.0
//
void CSound::setSoundPitchShift( unsigned int id, float shift )
{
	if( _soundEffectExists( id ) )
		SoundEffectsMap[id]->setPitchShift( shift );
}
//====================================================================

//--------------------------------------------------------------------
// Method: getSoundPitchShift()
// Desc: Returns the current sound pitch. range: 0.5 - 2.0, default: 1.0
//
float CSound::getSoundPitchShift( unsigned int id )
{
	if( _soundEffectExists( id ) )
		return SoundEffectsMap[id]->getPitchShift();
	return 1.0;
}
//====================================================================

//--------------------------------------------------------------------
// Method: playMusic()
// Desc: Starts playing the specified music.
//
void CSound::playMusic( unsigned int id )
{
	if( _musicExists( id ) )
		MusicMap[id]->play();
}
//====================================================================

//--------------------------------------------------------------------
// Method: stopMusic()
// Desc: Stops the specified music.
//
void CSound::stopMusic( unsigned int id )
{
	if( _musicExists( id ) )
		MusicMap[id]->stop();
}
//====================================================================

//--------------------------------------------------------------------
// Method: isMusicPlaying()
// Desc: Returns whether the music is currently playing (true) or not
//
bool CSound::isMusicPlaying( unsigned int id )
{
	if( _musicExists( id ) )
		return MusicMap[id]->isPlaying();
	return false;
}
//====================================================================

//--------------------------------------------------------------------
// Method: resetMusic
// Desc: Resets the music to the begining.
//
void CSound::resetMusic( unsigned int id )
{
	if( _musicExists( id ) )
		MusicMap[id]->reset();
}
//====================================================================

//--------------------------------------------------------------------
// Method: setMusicRepeat()
// Desc: sets whether the specified music should be repeated (true)
//	or not.
//
void CSound::setMusicRepeat( unsigned int id, bool repeat )
{
	if( _musicExists( id ) )
		MusicMap[id]->setRepeat( repeat );
}
//====================================================================

//--------------------------------------------------------------------
// Method: getMusicRepeat()
// Desc: Returns whether the specified music is set to auro-repeat.
//
bool CSound::getMusicRepeat( unsigned int id )
{
	if( _musicExists( id ) )
		return MusicMap[id]->getRepeat();
	return false;
}
//====================================================================

//--------------------------------------------------------------------
// Method: setMusicVolume()
// Desc: sets the music volume. lowest: 0.0, highest: 1.0
//
void CSound::setMusicVolume( unsigned int id, float volume )
{
	if( _musicExists( id ) )
		MusicMap[id]->setVolume( volume );
}
//====================================================================

//--------------------------------------------------------------------
// Method: getMusicVolume()
// Desc: Returns the current music volume.
//
float CSound::getMusicVolume( unsigned int id )
{
	if( _musicExists( id ) )
		return MusicMap[id]->getVolume();
	return 0.0f;
}
//====================================================================

//--------------------------------------------------------------------
// Method: setMusicPan()
// Desc: Sets pan for the specified music. left: -1.0, center: 0.0
//	,right: 1.0
//
void CSound::setMusicPan( unsigned int id, float pan )
{
	if( _musicExists( id ) )
		MusicMap[id]->setPan( pan );
}
//====================================================================

//--------------------------------------------------------------------
// Method: getMusicMap
// Desc: Returns the panning of the specified music. left: -1.0
//	,center: 0.0 ,right: 1.0
//
float CSound::getMusicPan( unsigned int id )
{
	if( _musicExists( id  ) )
		return MusicMap[id]->getPan();
	return 0.0f;
}
//====================================================================

//--------------------------------------------------------------------
// Method: setMusicPitchShift()
// Desc: Sets the pitch of the specified music. range: 0.5 - 2.0,
//	default: 1.0
//
void CSound::setMusicPitchShift( unsigned int id, float shift )
{
	if( _musicExists( id ) )
		MusicMap[id]->setPitchShift( shift );
}
//====================================================================

//--------------------------------------------------------------------
// Method: getMusicPitchShift()
// Desc: Returns the current pitch of the specified music.
//	range: 0.5 - 2.0, default: 1.0
//
float CSound::getMusicPitchShift( unsigned int id )
{
	if( _musicExists( id ) )
		return MusicMap[id]->getPitchShift();
	return 1.0;
}
//====================================================================

//--------------------------------------------------------------------
// Method: isMusicSeekable()
// Desc: Returns whether the music is seekable.
//
bool CSound::isMusicSeekable( unsigned int id )
{
	if( _musicExists( id ) )
		return MusicMap[id]->isSeekable();
	return false;
}
//====================================================================

//--------------------------------------------------------------------
// Method: getMusicLength()
// Desc: Returns the music length in integer.
//
int CSound::getMusicLength( unsigned int id )
{
	if( _musicExists( id ) )
		return MusicMap[id]->getLength();
	return 0;
}
//====================================================================

//--------------------------------------------------------------------
// Method: setMusicPosition()
// Desc: Sets the playing position.
//
void CSound::setMusicPosition( unsigned int id, int position )
{
	if( _musicExists( id ) )
		MusicMap[id]->setPosition( position );
}
//====================================================================

//--------------------------------------------------------------------
// Method: getMusicPosition()
// Desc: Gets the playing position.
//
int CSound::getMusicPosition( unsigned int id )
{
	if( _musicExists( id ) )
		return MusicMap[id]->getPosition();
	return 0;
}
//====================================================================

//--------------------------------------------------------------------
// Method: Some Method
// Desc: it's description
//
//====================================================================

//--------------------------------------------------------------------END


