/*************************************************************
 * Character Animation Article
 *
 * Title: World Object
 *
 * Author: Salwan A. AlHelaly
 *
 *************************************************************/

#ifndef __STAGE_H__
#define __STAGE_H__

#include "d3dUtility.h"
#include "vincent.h"
#include "timer.h"
#include "geometry.h"
#include "sound.h"

// ����� ����� ��� ����� ������ ��� ��� ���� ��� ������
#define WINDOWX				800
#define WINDOWY				600
#define FULLSCREEN			false

enum EStage
{
	E_STAGE_1 = 0,
	E_STAGE_2,
};

enum EStageState
{
	E_STAGE_BEGIN = 0,

	E_STAGE1_PUZZLE_START,
	E_STAGE1_PLAY_SEQUENCE,
	E_STAGE1_WAIT_FOR_INPUT,
	E_STAGE1_CORRECT_INPUT,
	E_STAGE1_WRONG_INPUT,
	E_STAGE1_PUZZLE_SOLVED,
	E_STAGE1_WALL_OPEN,

	E_STAGE2_WAIT_FOR_INPUT,
	E_STAGE2_CREDITS,

	E_STAGE_END,
};

enum ESceneGeometry
{
	E_STAGE1_STARTING_GROUND = 0,
	E_STAGE1_PUZZLE_GROUND,
	E_STAGE1_PUZZLE_WALL,
	E_STAGE1_BOX_LOW,
	E_STAGE1_BOX_HIGH,
	E_STAGE1_GLYPHS_WALL,

	E_STAGE1_GLYPH_1_WALL,
	E_STAGE1_GLYPH_2_WALL,
	E_STAGE1_GLYPH_3_WALL,
	E_STAGE1_GLYPH_4_WALL,
	E_STAGE1_GLYPH_1_NOGLOW,
	E_STAGE1_GLYPH_2_NOGLOW,
	E_STAGE1_GLYPH_3_NOGLOW,
	E_STAGE1_GLYPH_4_NOGLOW,
	E_STAGE1_GLYPH_1_GLOW,
	E_STAGE1_GLYPH_2_GLOW,
	E_STAGE1_GLYPH_3_GLOW,
	E_STAGE1_GLYPH_4_GLOW,
	E_STAGE1_GLYPH_GROUND_UP,
	E_STAGE1_GLYPH_GROUND_DOWN,

	E_STAGE2_GROUND,
};

enum ESoundEffects
{
	E_GLYPH_GLOW = 1,
	E_GLYPH_COMPLETE,
	E_GLYPH_KEY,
	E_GLYPH_ERROR,
	E_PUZZLE_SOLVED,
	E_WALL_OPEN,
};

struct StageBoundary
{
	StageBoundary() { }
	StageBoundary(float minx, float maxx, float minz, float maxz)
	{
		minX = minx;
		maxX = maxx;
		minZ = minz;
		maxZ = maxz;
	}
	float minX;
	float maxX;
	float minZ;
	float maxZ;
};

class CWorld
{
public:
	CWorld(IDirect3DDevice9* Device);
	virtual ~CWorld();

	void update(float timeDelta);
	void render();

	const D3DLIGHT9& getSceneLight() const { return mSceneLight; }
	const D3DXMATRIX& getViewMatrix() const { return mViewMatrix; }
	const D3DXMATRIX& getProjectionMatrix() const { return mProjMatrix; }

	const StageBoundary getStageBoundary();

	void triggerAction(bool action) { m_bActionTriggered = action; }

private:
	void createWorld();
	void renderWorld();

	void createStage1();
	void destroyStage1();
	const StageBoundary getStage1Boundary() const;
	void updateStage1();
	void renderStage1();
	void renderStage1Alpha();

	void stage1PuzzleStart();
	void stage1PlaySequence();
	void stage1WaitForInput();
	void stage1WrongInput();
	void stage1CorrectInput();
	void stage1PuzzleSolved();
	void stage1WallOpen();

	
	void createStage2();
	void destroyStage2();
	const StageBoundary getStage2Boundary() const;
	void updateStage2();
	void renderStage2();
	void renderStage2Alpha();

	void stage2WaitForInput();
	void stage2Credits();
	void renderStage2Overlay();

	LPDIRECT3DDEVICE9			mDevice;
	CD3DFont*					mD3DFont;
	geometry::D3DGeometryContainer*	mGC;
	CSound*						mAudio;

	LPDIRECT3DTEXTURE9			mEndTexture;;
	
	D3DLIGHT9					mSceneLight;
	D3DXMATRIX					mProjMatrix;
	D3DXMATRIX					mViewMatrix;

	EStage						m_eCurrentStage;
	EStageState					m_eStage1State;
	EStageState					m_eStage2State;

	CVincent*					mVincent;

	unsigned int				m_uFrameCount;
	float						m_fFPSFrameTimer;
	unsigned int				m_uFPS;

	CTimer						mTimer;

	int							m_iGenericState;

	unsigned int				m_uCurrentGlyph;
	std::vector<int>			m_iPuzzleKeys;
	unsigned int				m_uCurrentKey;
	unsigned int				m_uInputKey;
	std::vector<int>			m_iInputVector;
	unsigned int				m_uCounter;

	bool						m_bPressedKeys;
	bool						m_bActionTriggered;

	float						m_fWallYOffset;

	float						m_fAnimatedValue[10];
};

#endif