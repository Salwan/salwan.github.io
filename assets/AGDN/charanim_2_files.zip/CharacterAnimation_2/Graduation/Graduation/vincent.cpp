/*************************************************************
 * Character Animation Article
 *
 * Title: Vincent Object
 *
 * Author: Salwan A. AlHelaly
 *
 *************************************************************/

#include "vincent.h"
#include "world.h"

//
// Definitions
//
CalCoreModel*			CVincent::mCoreModel = NULL;
int						CVincent::m_iModelInstanceCount = 0;

LPDIRECT3DVERTEXSHADER9	CVincent::mVShader = NULL;
LPD3DXCONSTANTTABLE		CVincent::mVShaderConstTable = NULL;
LPDIRECT3DVERTEXDECLARATION9 CVincent::mVertexDeclaration = NULL;
D3DXHANDLE				CVincent::mBonesMatrixHandle = 0;
D3DXHANDLE				CVincent::mWorldViewProjMatrixHandle = 0;
D3DXHANDLE				CVincent::mWorldViewMatrixHandle = 0;
D3DXHANDLE				CVincent::mLightDirectionHandle = 0;
D3DXHANDLE				CVincent::mAmbientLightIntensityHandle = 0;
D3DXHANDLE				CVincent::mDiffuseLightIntensityHandle = 0;
D3DXHANDLE				CVincent::mAmbientMtrlHandle = 0;
D3DXHANDLE				CVincent::mDiffuseMtrlHandle = 0;

struct VincentVertex
{
	D3DXVECTOR3			vPosition;
	float				vWeights [4];
	float				vIndices [4];
	D3DXVECTOR3			vNormal;
	D3DXVECTOR2			vTexCoords;
};

const D3DVERTEXELEMENT9 VincentVertexElements [] =
{
	{ 0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
	{ 0, 12, D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_BLENDWEIGHT, 0 },
	{ 0, 28, D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_BLENDINDICES, 0 },
	{ 0, 44, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL, 0 },
	{ 0, 56, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 },
	D3DDECL_END()
};

//
// Class CVincent Implementation
//
CVincent::CVincent(IDirect3DDevice9* device, CWorld* world) : 
	mDevice(device), mWorld(world),
	mVB(NULL), mIB(NULL),
	m_vPosition(D3DXVECTOR3(0.0f, 0.0f, 0.0f)), 
	m_vDirection(D3DXVECTOR3(0.0f, 0.0f, 1.0f)),
	m_fRotation(0.0f),
	m_eCurrentAnimationState(E_ANIMSTAT_IDLE),
	m_fSpeed(0.0f),
	m_bHasControl(false)
{
	assert(mDevice != NULL);
	assert(mWorld != NULL);

	// ����� ���� ������� ������� �� �� ��� ��� ������
	if(!CVincent::mCoreModel)
	{
		mCoreModel = new CalCoreModel("Vincent");
		loadVincentData();
	}

	// ����� ���� �������	
	createModelInstance();
}

CVincent::~CVincent()
{
	SAFEDELETE(mHardwareModel);
	SAFEDELETE(mModel);

	SAFERELEASE(mVB);
	SAFERELEASE(mIB);

	// ��� ���� ��� ��� ����� ������ �� �������� ����������
	CVincent::m_iModelInstanceCount--;
	if(CVincent::m_iModelInstanceCount <= 0)
	{
		SAFEDELETE(CVincent::mCoreModel);
		SAFERELEASE(CVincent::mVShader);
		SAFERELEASE(CVincent::mVShaderConstTable);
		SAFERELEASE(CVincent::mVertexDeclaration);
	}
}

void CVincent::update(float timeDelta)
{
	if(m_bHasControl)
	{
		animationStateMachine();
		if(Key('W'))
		{
			m_vPosition += m_vDirection * (m_fSpeed * timeDelta);
		}
		else
		if(Key('S'))
		{
			m_vPosition -= m_vDirection * (m_fSpeed * timeDelta);
		}
		if(Key('A'))
		{
			float angle = timeDelta * 2.0f;
			m_fRotation -= angle;
			if(m_fRotation < 0)
			{
				m_fRotation += RADIAN(360);
			}
			D3DXMATRIX mat;
			D3DXMatrixRotationY(&mat, -angle);
			D3DXVec3TransformNormal(&m_vDirection, &m_vDirection, &mat);
			m_vDirection.y = 0.0f;
			D3DXVec3Normalize(&m_vDirection, &m_vDirection);
		}
		if(Key('D'))
		{
			float angle = timeDelta * 2.0f;
			m_fRotation += angle;
			if(m_fRotation > RADIAN(360))
			{
				m_fRotation -= RADIAN(360);
			}
			D3DXMATRIX mat;
			D3DXMatrixRotationY(&mat, angle);
			D3DXVec3TransformNormal(&m_vDirection, &m_vDirection, &mat);
			m_vDirection.y = 0.0f;
			D3DXVec3Normalize(&m_vDirection, &m_vDirection);
		}

		if(Key(VK_SPACE))
		{
			mWorld->triggerAction(true);
		}
		else
		{
			mWorld->triggerAction(false);
		}

		applyStageBoundary();
	}
	mModel->update(timeDelta);
}

void CVincent::render()
{
	int hardwareMeshId, boneId;
	unsigned char ambientColor[4], diffuseColor[4];
	D3DXCOLOR d3dAmbientColor, d3dDiffuseColor;
	D3DXMATRIX world, mat1, mat2;
	D3DXMATRIX view = mWorld->getViewMatrix();
	D3DXMATRIX projection = mWorld->getProjectionMatrix();
	CalVector boneTranslation;

	D3DXMatrixRotationYawPitchRoll(&mat1, m_fRotation, RADIAN(-90), 0.0f);
	D3DXMatrixTranslation(&mat2, m_vPosition.x, m_vPosition.y, m_vPosition.z);
	world = mat1 * mat2;

	mat1 = world * view;
	mat2 = mat1 * projection;

	CVincent::mVShaderConstTable->SetMatrix(mDevice, CVincent::mWorldViewMatrixHandle, &mat1);
	CVincent::mVShaderConstTable->SetMatrix(mDevice, CVincent::mWorldViewProjMatrixHandle, &mat2);

	const D3DLIGHT9 light = mWorld->getSceneLight();
	CVincent::mVShaderConstTable->SetVector(mDevice, CVincent::mLightDirectionHandle, (D3DXVECTOR4*)&light.Direction);
	CVincent::mVShaderConstTable->SetVector(mDevice, CVincent::mAmbientLightIntensityHandle, (D3DXVECTOR4*)&light.Ambient);
	CVincent::mVShaderConstTable->SetVector(mDevice, CVincent::mDiffuseLightIntensityHandle, (D3DXVECTOR4*)&light.Diffuse);

	mDevice->SetVertexShader(CVincent::mVShader);
	mDevice->SetVertexDeclaration(CVincent::mVertexDeclaration);
	mDevice->SetStreamSource(0, CVincent::mVB, 0, sizeof(VincentVertex));
	mDevice->SetIndices(CVincent::mIB);
	mDevice->SetTexture(0, 0);
	
	for(hardwareMeshId = 0; hardwareMeshId < mHardwareModel->getHardwareMeshCount(); hardwareMeshId++)
	{
		mHardwareModel->selectHardwareMesh(hardwareMeshId);

		mHardwareModel->getAmbientColor(&ambientColor[0]);
		mHardwareModel->getDiffuseColor(&diffuseColor[0]);

		d3dAmbientColor = D3DXCOLOR(Color_Cal3DToD3D(ambientColor));
		d3dDiffuseColor = D3DXCOLOR(Color_Cal3DToD3D(&diffuseColor[0]));

		CVincent::mVShaderConstTable->SetVector(mDevice, CVincent::mAmbientMtrlHandle, (D3DXVECTOR4*)&d3dAmbientColor);
		CVincent::mVShaderConstTable->SetVector(mDevice, CVincent::mDiffuseMtrlHandle, (D3DXVECTOR4*)&d3dDiffuseColor);
		
		for(boneId = 0; boneId < mHardwareModel->getBoneCount(); boneId++)
		{
			D3DXMatrixRotationQuaternion(&mat1, (const D3DXQUATERNION*)&mHardwareModel->getRotationBoneSpace(boneId,
				mModel->getSkeleton()));

			boneTranslation = mHardwareModel->getTranslationBoneSpace(boneId, mModel->getSkeleton());

			mat1._14 = boneTranslation.x;
			mat1._24 = boneTranslation.y;
			mat1._34 = boneTranslation.z;

			CVincent::mVShaderConstTable->SetFloatArray(
				mDevice, 
				CVincent::mVShaderConstTable->GetConstantElement(CVincent::mBonesMatrixHandle, boneId),
				&mat1._11, 
				12);
		}

		mDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST,
			mHardwareModel->getBaseVertexIndex(), 0, mHardwareModel->getVertexCount(),
			mHardwareModel->getStartIndex(), mHardwareModel->getFaceCount());
	}

	// ���� ������ ������ ����� ������ ��� ���� ���� ��������
	mDevice->SetVertexShader(NULL);
	mDevice->SetVertexDeclaration(NULL);
	mDevice->SetIndices(NULL);
}

void CVincent::enableControl()
{
	m_bHasControl = true;
}

void CVincent::disableControl()
{
	m_bHasControl = false;
	resetAnimationSequence();
}

// (Idle) ���� ������ ������� ����� ��� ��� ���� ������
void CVincent::resetAnimationSequence()
{
	switch(m_eCurrentAnimationState)
	{
	case E_ANIMSTAT_IDLE:
		return;
	case E_ANIMSTAT_WALK:
		mModel->getMixer()->clearCycle(m_iAnimationID [E_ANIMSEQ_WALK], 0.3f);
		break;
	case E_ANIMSTAT_RUN:
		mModel->getMixer()->clearCycle(m_iAnimationID [E_ANIMSEQ_RUN], 0.3f);
		break;
	}
	m_eCurrentAnimationState = E_ANIMSTAT_IDLE;
	mModel->getMixer()->blendCycle(m_iAnimationID [E_ANIMSEQ_IDLE], 1.0f, 0.3f);
}

void CVincent::animationStateMachine()
{
	switch(m_eCurrentAnimationState)
	{
	case E_ANIMSTAT_IDLE:
		m_fSpeed = 0.0f;
		if(Key('W') || Key('S'))
		{
			// Go Walk
			m_eCurrentAnimationState = E_ANIMSTAT_WALK;
			mModel->getMixer()->blendCycle(m_iAnimationID [E_ANIMSEQ_WALK], 1.0f, 0.3f);
			mModel->getMixer()->clearCycle(m_iAnimationID [E_ANIMSEQ_IDLE], 0.3f);
		}
		break;
	case E_ANIMSTAT_WALK:
		m_fSpeed = 30.0f;
		if(!Key('W') && !Key('S'))
		{
			// Go Idle
			m_eCurrentAnimationState = E_ANIMSTAT_IDLE;
			mModel->getMixer()->blendCycle(m_iAnimationID [E_ANIMSEQ_IDLE], 1.0f, 0.3f);
			mModel->getMixer()->clearCycle(m_iAnimationID [E_ANIMSEQ_WALK], 0.3f);
		}
		else
		if(Key('W') && Key(VK_SHIFT))
		{
			// Go Run
			m_eCurrentAnimationState = E_ANIMSTAT_RUN;
			mModel->getMixer()->blendCycle(m_iAnimationID [E_ANIMSEQ_RUN], 1.0f, 0.3f);
			mModel->getMixer()->clearCycle(m_iAnimationID [E_ANIMSEQ_WALK], 0.3f);
		}
		break;
	case E_ANIMSTAT_RUN:
		m_fSpeed = 95.0f;
		if(!Key(VK_SHIFT) && (Key('W') || Key('S')) )
		{
			// Go Walk
			m_eCurrentAnimationState = E_ANIMSTAT_WALK;
			mModel->getMixer()->blendCycle(m_iAnimationID [E_ANIMSEQ_WALK], 1.0f, 0.3f);
			mModel->getMixer()->clearCycle(m_iAnimationID [E_ANIMSEQ_RUN], 0.3f);
		}
		else
		if(!Key('W'))
		{
			// Go Idle
			m_eCurrentAnimationState = E_ANIMSTAT_IDLE;
			mModel->getMixer()->blendCycle(m_iAnimationID [E_ANIMSEQ_IDLE], 1.0f, 0.3f);
			mModel->getMixer()->clearCycle(m_iAnimationID [E_ANIMSEQ_RUN], 0.3f);
		}
		break;
	}
}

void CVincent::loadVincentData()
{
	bool result;
	int i;
	int materialID [7];

	result = CVincent::mCoreModel->loadCoreSkeleton("vincent/vincent.csf");
	if(!result) throw std::wstring(L"CVincent: Could not find skeleton file:\nvincent\\vincent_skeleton.csf");

	m_iAnimationID [E_ANIMSEQ_IDLE]		= CVincent::mCoreModel->loadCoreAnimation("vincent/vincent_idle.caf");
	m_iAnimationID [E_ANIMSEQ_WALK]		= CVincent::mCoreModel->loadCoreAnimation("vincent/vincent_walk.caf");
	m_iAnimationID [E_ANIMSEQ_RUN]		= CVincent::mCoreModel->loadCoreAnimation("vincent/vincent_run.caf");
	m_iAnimationID [E_ANIMSEQ_SNEAK]	= CVincent::mCoreModel->loadCoreAnimation("vincent/vincent_sneak.caf");

	if(m_iAnimationID[E_ANIMSEQ_IDLE] == -1)	throw std::wstring(L"CVincent: Could not load idle animation file:\nvincent\\vincent_idle.caf");
	if(m_iAnimationID[E_ANIMSEQ_WALK] == -1)	throw std::wstring(L"CVincent: Could not load walk animation file:\nvincent\\vincent_walk.caf");
	if(m_iAnimationID[E_ANIMSEQ_RUN] == -1)		throw std::wstring(L"CVincent: Could not load run animation file:\nvincent\\vincent_run.caf");
	if(m_iAnimationID[E_ANIMSEQ_SNEAK] == -1)	throw std::wstring(L"CVincent: Could not load sneak animation file:\nvincent\\vincent_sneak.caf");

	m_iMeshID = CVincent::mCoreModel->loadCoreMesh("vincent/vincent_mesh.cmf");
	
	if(m_iMeshID == -1)	throw std::wstring(L"CVincent: Could not load mesh file:\nvincent\\vincent_mesh.cmf");

	materialID [0]	= CVincent::mCoreModel->loadCoreMaterial("vincent/material_0.crf");
	materialID [1]	= CVincent::mCoreModel->loadCoreMaterial("vincent/material_1.crf");
	materialID [2]	= CVincent::mCoreModel->loadCoreMaterial("vincent/material_2.crf");
	materialID [3]	= CVincent::mCoreModel->loadCoreMaterial("vincent/material_3.crf");
	materialID [4]	= CVincent::mCoreModel->loadCoreMaterial("vincent/material_4.crf");
	materialID [5]	= CVincent::mCoreModel->loadCoreMaterial("vincent/material_5.crf");
	materialID [6]	= CVincent::mCoreModel->loadCoreMaterial("vincent/material_6.crf");

	if(materialID[0] == -1)	throw std::wstring(L"CVincent: Could not load material 0 file:\nvincent\\material_0.crf");
	if(materialID[1] == -1)	throw std::wstring(L"CVincent: Could not load material 1 file:\nvincent\\material_1.crf");
	if(materialID[2] == -1)	throw std::wstring(L"CVincent: Could not load material 2 file:\nvincent\\material_2.crf");
	if(materialID[3] == -1)	throw std::wstring(L"CVincent: Could not load material 3 file:\nvincent\\material_3.crf");
	if(materialID[4] == -1)	throw std::wstring(L"CVincent: Could not load material 4 file:\nvincent\\material_4.crf");
	if(materialID[5] == -1)	throw std::wstring(L"CVincent: Could not load material 5 file:\nvincent\\material_5.crf");
	if(materialID[6] == -1)	throw std::wstring(L"CVincent: Could not load material 6 file:\nvincent\\material_6.crf");

	for(i = 0; i < CVincent::mCoreModel->getCoreMaterialCount(); i++)
	{
		CVincent::mCoreModel->createCoreMaterialThread(i);
		CVincent::mCoreModel->setCoreMaterialId(i, 0, materialID [i]);
	}
}

void CVincent::createModelInstance()
{
	HRESULT hr;
	int i;
	int vertexCount = 0, faceCount = 0;
	D3DFORMAT indicesFormat;

	CVincent::m_iModelInstanceCount++;
	mModel = new CalModel(CVincent::mCoreModel);
	mModel->setLodLevel(1.0f);
	mModel->attachMesh(m_iMeshID);
	mModel->setMaterialSet(0);
	mModel->getMixer()->blendCycle(m_iAnimationID [0], 1.0f, 0.0f);

	CalRenderer* modelRenderer = mModel->getRenderer();
	CalMesh* modelMesh = mModel->getMesh(m_iMeshID);
	for(i = 0; i < modelMesh->getSubmeshCount(); i++)
	{
		modelRenderer->selectMeshSubmesh(m_iMeshID, i);
		vertexCount += modelRenderer->getVertexCount();
		faceCount += modelRenderer->getFaceCount();
	}	

	hr = mDevice->CreateVertexBuffer(sizeof(VincentVertex) * vertexCount,
		D3DUSAGE_WRITEONLY, 0, D3DPOOL_DEFAULT, &mVB, 0);
	if(FAILED(hr))	throw std::wstring(L"CVincent: Could not create the vertex buffer");

	if(sizeof(CalIndex) == 4)
	{
		indicesFormat = D3DFMT_INDEX32;
	}
	else
	{
		indicesFormat = D3DFMT_INDEX16;
	}

	hr = mDevice->CreateIndexBuffer(sizeof(CalIndex) * faceCount * 3,
		D3DUSAGE_WRITEONLY, indicesFormat, D3DPOOL_DEFAULT, &mIB, 0);
	if(FAILED(hr))	throw std::wstring(L"CVincent: Could not create the index buffer");

	mHardwareModel = new CalHardwareModel(CVincent::mCoreModel);

	VincentVertex* vertices = NULL;
	CalIndex* indices = NULL;

	hr = mVB->Lock(0, 0, (void**)&vertices, D3DLOCK_DISCARD);
	if(FAILED(hr))	throw std::wstring(L"CVincent: Could not lock the vertex buffer");

	hr = mIB->Lock(0, 0, (void**)&indices, D3DLOCK_DISCARD);
	if(FAILED(hr))	throw std::wstring(L"CVincent: Could not lock the index buffer");

	mHardwareModel->setVertexBuffer((char*)vertices, sizeof(VincentVertex));
	mHardwareModel->setWeightBuffer(((char*)vertices) + 12, sizeof(VincentVertex));
	mHardwareModel->setMatrixIndexBuffer(((char*)vertices) + 28, sizeof(VincentVertex));
	mHardwareModel->setNormalBuffer(((char*)vertices) + 44, sizeof(VincentVertex));
	mHardwareModel->setTextureCoordNum(1);
	mHardwareModel->setTextureCoordBuffer(0, ((char*)vertices) + 56, sizeof(VincentVertex));
	mHardwareModel->setIndexBuffer(indices);
	mHardwareModel->load(0, 0, MAX_BONES_PER_MESH);

	mVB->Unlock();
	mIB->Unlock();

	createVertexShader();
}

void CVincent::createVertexShader()
{
	if(!CVincent::mVShader && CVincent::m_iModelInstanceCount == 1)
	{
		HRESULT hr;
		LPD3DXBUFFER vshaderBuffer = NULL, errorBuffer = NULL;
		WCHAR errorString [255];

		hr = mDevice->CreateVertexDeclaration(VincentVertexElements, &CVincent::mVertexDeclaration);
		if(FAILED(hr))	throw std::wstring(L"CVincent: Could not create vertex declaration");

		hr = D3DXCompileShaderFromFile(
			L"cal3d_skin_vs.fx", 0, 0, "main", "vs_2_0", D3DXSHADER_DEBUG, &vshaderBuffer,
			&errorBuffer, &CVincent::mVShaderConstTable);
		if(errorBuffer)
		{
			wsprintf(errorString, L"CVincent: Error compiling vertex shader:\n%hs", errorBuffer->GetBufferPointer());
		}
		if(FAILED(hr))	throw std::wstring(errorString);

		hr = mDevice->CreateVertexShader((DWORD*)vshaderBuffer->GetBufferPointer(), &CVincent::mVShader);
		if(FAILED(hr))	throw std::wstring(L"CVincent: Could not create vertex shader");

		SAFERELEASE(vshaderBuffer);

		CVincent::mBonesMatrixHandle			= CVincent::mVShaderConstTable->GetConstantByName(0, "BonesMatrix");
		CVincent::mWorldViewProjMatrixHandle	= CVincent::mVShaderConstTable->GetConstantByName(0, "WorldViewProjMatrix");
		CVincent::mWorldViewMatrixHandle		= CVincent::mVShaderConstTable->GetConstantByName(0, "WorldViewMatrix");
		CVincent::mLightDirectionHandle			= CVincent::mVShaderConstTable->GetConstantByName(0, "LightDirection");
		CVincent::mAmbientLightIntensityHandle	= CVincent::mVShaderConstTable->GetConstantByName(0, "AmbientLightIntensity");
		CVincent::mDiffuseLightIntensityHandle	= CVincent::mVShaderConstTable->GetConstantByName(0, "DiffuseLightIntensity");
		CVincent::mAmbientMtrlHandle			= CVincent::mVShaderConstTable->GetConstantByName(0, "AmbientMtrl");
		CVincent::mDiffuseMtrlHandle			= CVincent::mVShaderConstTable->GetConstantByName(0, "DiffuseMtrl");

		CVincent::mVShaderConstTable->SetDefaults(mDevice);
	}
}

void CVincent::applyStageBoundary()
{
	const StageBoundary sb = mWorld->getStageBoundary();
	m_vPosition.x = CAP(m_vPosition.x, sb.minX + 20.0f, sb.maxX - 20.0f);
	m_vPosition.z = CAP(m_vPosition.z, sb.minZ + 20.0f, sb.maxZ - 20.0f);
}