#include "world.h"

//
// Definitions
//

//
// CWorld Implementation
//

CWorld::CWorld(IDirect3DDevice9* Device) : mDevice(Device),mVincent(NULL),
	m_eCurrentStage(E_STAGE_1), mD3DFont(NULL),
	m_eStage1State(E_STAGE_BEGIN),
	m_iGenericState(0), m_uCurrentKey(INT_MAX), m_eStage2State(E_STAGE_BEGIN),
	m_bPressedKeys(false), m_bActionTriggered(false),
	m_uInputKey(0), m_uCurrentGlyph(0), m_fWallYOffset(0.0f), m_uCounter(0)
{
	assert(mDevice);
	
	mD3DFont = new CD3DFont(L"Times New Roman", 12, D3DFONT_BOLD);
	mD3DFont->InitDeviceObjects(Device);
	mD3DFont->RestoreDeviceObjects();
	
	mAudio = new CSound();
	mAudio->Init();

	createWorld();

	m_uFrameCount = 0;
	m_fFPSFrameTimer = 0.0f;
	m_uFPS = 0;

	memset(m_fAnimatedValue, 0, sizeof(float) * 10);

	srand(timeGetTime());
}

CWorld::~CWorld()
{
	destroyStage1();
	destroyStage2();
	mD3DFont->InvalidateDeviceObjects();
	mD3DFont->DeleteDeviceObjects();
	SAFEDELETE(mD3DFont);
	SAFEDELETE(mGC);
	SAFEDELETE(mVincent);
	mAudio->Cleanup();
	SAFEDELETE(mAudio);
}

void CWorld::createWorld()
{
	D3DXMatrixPerspectiveFovLH(&mProjMatrix, D3DX_PI*0.25f, 
			(float)WINDOWX/(float)WINDOWY, 1.0f, 1000.0f);
	D3DXMatrixLookAtLH(&mViewMatrix, &D3DXVECTOR3(0.0f, 75.0f, -100.0f), 
			&D3DXVECTOR3(0.0f, 35.0f, 0.0f), &D3DXVECTOR3(0.0f, 1.0f, 0.0f));

	mDevice->SetRenderState(D3DRS_LIGHTING, true);
	
	mSceneLight = d3d::InitDirectionalLight(&D3DXVECTOR3(0.0f, -0.5f, 1.0f),
		&D3DXCOLOR(0.9f, 0.9f, 0.9f, 1.0f));
	mDevice->SetLight(0, &mSceneLight);
	mDevice->LightEnable(0, true);

	mVincent = new CVincent(mDevice, this);
	mVincent->enableControl();

	mGC = new geometry::D3DGeometryContainer(mDevice);
	
	// Creating Scene Geometry
	// - E_STAGE1_STARTING_GROUND
	mGC->add(E_STAGE1_STARTING_GROUND, geometry::createBox(300.0f, 120.0f, 60.0f, 3.0f, 1.0f));
	mGC->giveTextureTo(E_STAGE1_STARTING_GROUND, L"textures/t6.jpg");
	// - E_STAGE1_PUZZLE_GROUND
	mGC->add(E_STAGE1_PUZZLE_GROUND, geometry::createQuad(300.0f, 300.0f, 5.0f, 6.0f));
	mGC->giveTextureTo(E_STAGE1_PUZZLE_GROUND, L"textures/t5.jpg");
	// - E_STAGE1_PUZZLE_WALL
	mGC->add(E_STAGE1_PUZZLE_WALL, geometry::createBox(300.0f, 150.0f, 250.0f, 5.0f, 3.0f));
	mGC->giveTextureTo(E_STAGE1_PUZZLE_WALL, L"textures/t13.jpg");
	// - E_STAGE1_BOX_LOW
	mGC->add(E_STAGE1_BOX_LOW, geometry::createBox(50.0f, 50.0f, 70.0f));
	mGC->giveTextureTo(E_STAGE1_BOX_LOW, L"textures/t7.jpg");
	// - E_STAGE1_BOX_HIGH
	mGC->add(E_STAGE1_BOX_HIGH, geometry::createBox(40.0f, 40.0f, 80.0f));
	mGC->giveTextureTo(E_STAGE1_BOX_HIGH, L"textures/t2.jpg");
	// - E_STAGE1_GLYPHS_WALL
	mGC->add(E_STAGE1_GLYPHS_WALL, geometry::createQuad(280.0f, 50.0f, 4.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPHS_WALL, L"textures/t8.jpg");

	// - E_STAGE1_GYLPH_1_WALL
	mGC->add(E_STAGE1_GLYPH_1_WALL, geometry::createQuad(40.0f, 40.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_1_WALL, L"textures/glyph1_wall.png");
	// - E_STAGE1_GYLPH_2_WALL
	mGC->add(E_STAGE1_GLYPH_2_WALL, geometry::createQuad(40.0f, 40.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_2_WALL, L"textures/glyph2_wall.png");
	// - E_STAGE1_GYLPH_3_WALL
	mGC->add(E_STAGE1_GLYPH_3_WALL, geometry::createQuad(40.0f, 40.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_3_WALL, L"textures/glyph3_wall.png");
	// - E_STAGE1_GYLPH_4_WALL
	mGC->add(E_STAGE1_GLYPH_4_WALL, geometry::createQuad(40.0f, 40.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_4_WALL, L"textures/glyph4_wall.png");

	// - E_STAGE1_GLYPH_1_NOGLOW
	mGC->add(E_STAGE1_GLYPH_1_NOGLOW, geometry::createQuad(40.0f, 40.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_1_NOGLOW, L"textures/glyph1_noglow.png");
	// - E_STAGE1_GLYPH_2_NOGLOW
	mGC->add(E_STAGE1_GLYPH_2_NOGLOW, geometry::createQuad(40.0f, 40.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_2_NOGLOW, L"textures/glyph2_noglow.png");
	// - E_STAGE1_GLYPH_3_NOGLOW
	mGC->add(E_STAGE1_GLYPH_3_NOGLOW, geometry::createQuad(40.0f, 40.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_3_NOGLOW, L"textures/glyph3_noglow.png");
	// - E_STAGE1_GLYPH_4_NOGLOW
	mGC->add(E_STAGE1_GLYPH_4_NOGLOW, geometry::createQuad(40.0f, 40.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_4_NOGLOW, L"textures/glyph4_noglow.png");

	// - E_STAGE1_GLYPH_1_GLOW
	mGC->add(E_STAGE1_GLYPH_1_GLOW, geometry::createQuad(40.0f, 40.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_1_GLOW, L"textures/glyph1_glow.png");
	// - E_STAGE1_GLYPH_2_GLOW
	mGC->add(E_STAGE1_GLYPH_2_GLOW, geometry::createQuad(40.0f, 40.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_2_GLOW, L"textures/glyph2_glow.png");
	// - E_STAGE1_GLYPH_3_GLOW
	mGC->add(E_STAGE1_GLYPH_3_GLOW, geometry::createQuad(40.0f, 40.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_3_GLOW, L"textures/glyph3_glow.png");
	// - E_STAGE1_GLYPH_4_GLOW
	mGC->add(E_STAGE1_GLYPH_4_GLOW, geometry::createQuad(40.0f, 40.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_4_GLOW, L"textures/glyph4_glow.png");

	// - E_STAGE1_GLYPH_GROUND_UP
	mGC->add(E_STAGE1_GLYPH_GROUND_UP, geometry::createBox(40.0f, 80.0f, 5.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_GROUND_UP, L"textures/glyph_ground_up.png");
	// - E_STAGE1_GLYPH_GROUND_DOWN
	mGC->add(E_STAGE1_GLYPH_GROUND_DOWN, geometry::createBox(40.0f, 80.0f, 5.0f));
	mGC->giveTextureTo(E_STAGE1_GLYPH_GROUND_DOWN, L"textures/glyph_ground_down.png");

	// - E_STAGE2_GROUND
	mGC->add(E_STAGE2_GROUND, geometry::createQuad(300.0f, 600.0f, 2, 4));
	mGC->giveTextureTo(E_STAGE2_GROUND, L"textures/t9.jpg");

	// Loading sounds
	// - E_GLYPH_GLOW
	mAudio->addSoundEffect("sounds/glyph_glow.ogg", true, E_GLYPH_GLOW);
	// - E_GLYPH_COMPLETE
	mAudio->addSoundEffect("sounds/glyph_complete.ogg", true, E_GLYPH_COMPLETE);
	// - E_GLYPH_KEY
	mAudio->addSoundEffect("sounds/glyph_key.ogg", true, E_GLYPH_KEY);
	// - E_GLYPH_ERROR
	mAudio->addSoundEffect("sounds/glyph_error.ogg", false, E_GLYPH_ERROR);
	// - E_PUZZLE_SOLVED
	mAudio->addSoundEffect("sounds/puzzle_solved.ogg", false, E_PUZZLE_SOLVED);
	// - E_WALL_OPEN
	mAudio->addSoundEffect("sounds/wall_open.ogg", false, E_WALL_OPEN);

	createStage1();
	createStage2();
}

void CWorld::update(float timeDelta)
{
	mTimer.Update(timeDelta);

	switch(m_eCurrentStage)
	{
	case E_STAGE_1:
		updateStage1();
		break;
	case E_STAGE_2:
		updateStage2();
		break;
	}

	mVincent->update(timeDelta);

	m_fFPSFrameTimer += timeDelta;
	m_uFrameCount++;
	if(m_fFPSFrameTimer > 1.0f)
	{
		m_uFPS = m_uFrameCount;
		m_uFrameCount = 0;
		m_fFPSFrameTimer -= 1.0f;
	}
}

void CWorld::render()
{
	WCHAR textBuffer[32];
	D3DXMATRIX mat;

	renderWorld();

	mVincent->render();

	wsprintf(textBuffer, L"FPS: %d", m_uFPS);
	mD3DFont->DrawTextW(0.0f, (float)WINDOWY - 24.0f, 0xffffffff, textBuffer, 0);

	if(m_eCurrentStage == E_STAGE_2 && m_eStage2State == E_STAGE2_CREDITS)
	{
		renderStage2Overlay();
	}
}

void CWorld::renderWorld()
{
	mDevice->SetTransform(D3DTS_VIEW, &mViewMatrix);
	mDevice->SetTransform(D3DTS_PROJECTION, &mProjMatrix);

	mDevice->SetMaterial(&d3d::WHITE_MTRL);
	mDevice->SetTexture(0, 0);

	mGC->setPosition(D3DXVECTOR3(0.0f, 0.0f, 810.0f));
	mGC->setRotation(D3DXVECTOR3(0.0f, 0.0f, 0.0f));
	mGC->draw(E_STAGE2_GROUND);
	
	mGC->setPosition(D3DXVECTOR3(0.0f, -30.0f, 0.0f));
	mGC->draw(E_STAGE1_STARTING_GROUND);

	mGC->setPosition(D3DXVECTOR3(0.0f, 0.0f, 210.0f));
	mGC->draw(E_STAGE1_PUZZLE_GROUND);

	mGC->setPosition(D3DXVECTOR3(0.0f, -25.0f + m_fWallYOffset, 435.0f));
	mGC->draw(E_STAGE1_PUZZLE_WALL);

	mGC->setPosition(D3DXVECTOR3(175.0f, -30.0f, 325.0f));
	mGC->draw(E_STAGE1_BOX_LOW);
	mGC->setPosition(D3DXVECTOR3(-175.0f, -30.0f, 325.0f));
	mGC->draw(E_STAGE1_BOX_LOW);

	mGC->setPosition(D3DXVECTOR3(175.0f, 35.0f, 325.0f));
	mGC->draw(E_STAGE1_BOX_HIGH);
	mGC->setPosition(D3DXVECTOR3(-175.0f, 35.0f, 325.0f));
	mGC->draw(E_STAGE1_BOX_HIGH);

	switch(m_eCurrentStage)
	{
	case E_STAGE_1:
		renderStage1();
		break;
	case E_STAGE_2:
		renderStage2();
		break;
	}

	// Alpha Blending
	mDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, true);
	mDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
	mDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
	mDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	mDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE); // Used for glow effect
	mDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);

	switch(m_eCurrentStage)
	{
	case E_STAGE_1:
		renderStage1Alpha();
		break;
	case E_STAGE_2:
		renderStage2Alpha();
		break;
	}

	mDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
}

const StageBoundary CWorld::getStageBoundary()
{
	switch(m_eCurrentStage)
	{
	case E_STAGE_1:
		return getStage1Boundary();
	case E_STAGE_2:
		return getStage2Boundary();
	}
	return StageBoundary();
}

void CWorld::createStage1()
{
}

void CWorld::destroyStage1()
{
}

const StageBoundary CWorld::getStage2Boundary() const
{
	return StageBoundary(-150.0f, 150.0f, -60.0f, 1110.0f);
}

void CWorld::updateStage1()
{
	D3DXVECTOR3 at = mVincent->getPosition();
	at.y = 35.0f;
	D3DXMatrixLookAtLH(&mViewMatrix, &D3DXVECTOR3(0.0f, 110.0f, -100.0f), 
			&at, &D3DXVECTOR3(0.0f, 1.0f, 0.0f));

	switch(m_eStage1State)
	{
	case E_STAGE_BEGIN:
		if(mVincent->getPosition().z > 75.0f)
		{
			m_eStage1State = E_STAGE1_PUZZLE_START;
			m_iGenericState = 0;
		}
		break;

	case E_STAGE1_PUZZLE_START:
		stage1PuzzleStart();
		break;

	case E_STAGE1_PLAY_SEQUENCE:
		stage1PlaySequence();
		break;

	case E_STAGE1_WAIT_FOR_INPUT:
		stage1WaitForInput();
		break;

	case E_STAGE1_WRONG_INPUT:
		stage1WrongInput();
		break;

	case E_STAGE1_CORRECT_INPUT:
		stage1CorrectInput();
		break;

	case E_STAGE1_PUZZLE_SOLVED:
		stage1PuzzleSolved();
		break;

	case E_STAGE1_WALL_OPEN:
		stage1WallOpen();
		break;

	case E_STAGE_END:
		m_eCurrentStage = E_STAGE_2;
		break;
	}
}

void CWorld::stage1PuzzleStart()
{
	int l, i;
	switch(m_iGenericState)
	{
	case 0:
		// Check for winning
		if(m_uCurrentGlyph == 4)
		{
			m_eStage1State = E_STAGE1_PUZZLE_SOLVED;
			return;
		}
		// Glow/playsound/form sequence/time 4 secs
		mAudio->playSound(E_GLYPH_GLOW);
		mTimer.AddTimer(0, 5.0f, &m_fAnimatedValue[0]);
		m_iGenericState++;
		// Form sequence of adaptive length that doesn't
		// have two similar consecutive numbers
		l = 3 + m_uCurrentGlyph;
		for(i = 0; i < l; i++)
		{
			m_iPuzzleKeys.push_back(rand() % 6);
			if(i > 0)
			{
				if(m_iPuzzleKeys[i] == m_iPuzzleKeys[i - 1])
				{
					m_iPuzzleKeys[i] += 1;
				}
				if(m_iPuzzleKeys[i] > 5)
				{
					m_iPuzzleKeys[i] = 0;
				}
			}
		}
		break;
	case 1:
		// Wait for 1 sec
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			mTimer.ChangeTime(0, 1.0f);
			m_iGenericState++;
		}
		break;
	case 2:
		m_eStage1State = E_STAGE1_PLAY_SEQUENCE;
		m_iGenericState = 0;
		mTimer.RemoveTimer(0);
		break;
	default:
		m_eStage1State = E_STAGE1_PLAY_SEQUENCE;
		m_iGenericState = 0;
		mTimer.RemoveTimer(0);
		break;
	}
}

void CWorld::stage1PlaySequence()
{
	switch(m_iGenericState)
	{
	case 0:
		mTimer.AddTimer(0, 1.0f, &m_fAnimatedValue[0]);
		m_iGenericState++;
		m_uCurrentKey = 0;
		break;

	case 1:
		// play key sequence
		if(m_uCurrentKey < m_iPuzzleKeys.size())
		{
			mTimer.ResetTimer(0);
			m_iGenericState = 2; // play!
			m_uInputKey = m_iPuzzleKeys[m_uCurrentKey];
			mAudio->setSoundPitchShift(E_GLYPH_KEY, 0.66f + (0.16f * m_uInputKey));
			mAudio->playSound(E_GLYPH_KEY);
			m_bPressedKeys = true;
		}
		else
		{
			m_iGenericState = 3; // done
			m_bPressedKeys = false;
		}
		break;

	case 2:
		// play note
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			m_iGenericState = 1;
			m_uCurrentKey++;
		}
		break;

	default:
		m_eStage1State = E_STAGE1_WAIT_FOR_INPUT;
		m_iGenericState = 0;
		mTimer.RemoveTimer(0);
	}
}

void CWorld::stage1WaitForInput()
{
	const float hw = 225.0f / 2.0f;
	const float cw = 225.0f / 5.0f;
	const float khw = 20.0f;
	const float khl = 40.0f;
	unsigned int i;
	float cx, cz;
	geometry::Rectf r;

	switch(m_iGenericState)
	{
	case 0:
		m_iInputVector.clear();
		mTimer.AddTimer(0, 1.0f, &m_fAnimatedValue[0]);
		m_iGenericState++;
		break;

	case 1:
		// Wait for Vincent to press a glyph key
		if(m_bActionTriggered)
		{
			// Is it within one of the glyph keys?
			for(i = 0; i < 6; i++)
			{
				cx = -hw + (i * cw);
				cz = 170.0f;
				r.left = cx - khw;
				r.top = cz + khl;
				r.right = cx + khw;
				r.bottom = cz - khl;
				if(r.collisionXZ(mVincent->getPosition()))
				{
					m_uInputKey = i;
					m_iGenericState = 2;
					mTimer.ChangeTime(0, 1.0f);
					mAudio->setSoundPitchShift(E_GLYPH_KEY, 0.66f + (0.16f * i));
					mAudio->playSound(E_GLYPH_KEY);
					m_bPressedKeys = true;
				}
			}
		}
		break;

	case 2:
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			m_bPressedKeys = false;
			m_iGenericState = 3;
		}
		break;

	case 3:
  		m_iInputVector.push_back(m_uInputKey);
		if(m_iInputVector.size() == m_iPuzzleKeys.size())
		{
			mTimer.ResetTimer(0);
			for(i = 0; i < m_iPuzzleKeys.size(); i++)
			{
				if(m_iInputVector[i] != m_iPuzzleKeys[i])
				{
					// Wrong code!
					m_iGenericState = 4;
					return;
				}
			}
			// If it reached here then you got it right!
			m_iGenericState = 5;
		}
		else
		{
			m_iGenericState = 1;
		}
		break;

	case 4:
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			m_eStage1State = E_STAGE1_WRONG_INPUT;
			m_iGenericState = 0;
			// Clear used data
			mTimer.RemoveTimer(0);
			m_iInputVector.clear();
			m_uInputKey = 0;
			m_bPressedKeys = false;
		}
		break;

	case 5:
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			m_eStage1State = E_STAGE1_CORRECT_INPUT;
			m_iGenericState = 0;
			// Clear used data
			mTimer.RemoveTimer(0);
			m_iInputVector.clear();
			m_uInputKey = 0;
			m_bPressedKeys = false;
		}
		break;

	default:
		m_iGenericState = 0;
		m_eStage1State = E_STAGE1_WRONG_INPUT;
	}
}

void CWorld::stage1WrongInput()
{
	switch(m_iGenericState)
	{
	case 0:
		mTimer.AddTimer(0, 1.0f, &m_fAnimatedValue[0]);
		m_iGenericState++;
		break;
	
	case 1:
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			mTimer.ChangeTime(0, 2.0f);
			mAudio->playSound(E_GLYPH_ERROR);
			m_iGenericState++;
		}
		break;

	case 2:
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			mTimer.RemoveTimer(0);
			m_eStage1State = E_STAGE1_PUZZLE_START;
			m_iGenericState = 0;
			m_iPuzzleKeys.clear();
		}
		break;
	}
}

void CWorld::stage1CorrectInput()
{
	switch(m_iGenericState)
	{
	case 0:
		mTimer.AddTimer(0, 1.0f, &m_fAnimatedValue[0]);
		m_iGenericState++;
		break;

	case 1:
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			mTimer.ChangeTime(0, 5.0f);
			m_iGenericState++;
			mAudio->playSound(E_GLYPH_COMPLETE);
		}
		break;

	case 2:
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			m_iGenericState++;
			m_uCurrentGlyph++;
		}
		break;

	case 3:
		mTimer.RemoveTimer(0);
		m_iGenericState = 0;
		m_eStage1State = E_STAGE1_PUZZLE_START;
		m_iPuzzleKeys.clear();
		break;
	}
}

void CWorld::stage1PuzzleSolved()
{
	switch(m_iGenericState)
	{
	case 0:
		// A little pause
		m_uCounter = 0;
		mTimer.AddTimer(0, 2.0f, &m_fAnimatedValue[0]);
		m_iGenericState++;
		break;

	case 1:
		// Glyph iteration
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			mTimer.ChangeTime(0, 3.0f);
			if(m_uCounter < m_uCurrentGlyph)
			{
				// render glyph
				m_iGenericState = 2;
				mAudio->playSound(E_PUZZLE_SOLVED);
			}
			else
			{
				// go wall open
				m_iGenericState = 3;
			}
		}
		break;

	case 2:
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			mTimer.ChangeTime(0, 0.5f);
			m_iGenericState = 1;
			m_uCounter++;
		}
		break;

	case 3:
		m_uCounter = 0;
		mTimer.RemoveTimer(0);
		m_iGenericState = 0;
		m_eStage1State = E_STAGE1_WALL_OPEN;
		break;
	}
}

void CWorld::stage1WallOpen()
{
	switch(m_iGenericState)
	{
	case 0:
		mTimer.AddTimer(0, 1.0f, &m_fAnimatedValue[0]);
		m_iGenericState++;
		break;
	case 1:
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			mAudio->playSound(E_GLYPH_ERROR);
			mTimer.ChangeTime(0, 0.5f);
			m_iGenericState++;
		}
		break;
	case 2:
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			mAudio->playSound(E_PUZZLE_SOLVED);
			mAudio->playSound(E_WALL_OPEN);
			mTimer.RemoveTimer(0);
			mTimer.AddTimer(1, 5.0f, &m_fAnimatedValue[1]);
			m_iGenericState++;
		}
	case 3:
		if(m_fAnimatedValue[1] >= 1.0f)
		{
			mAudio->playSound(E_GLYPH_ERROR);
			m_iGenericState++;
			m_fWallYOffset = -100.0f;
		}
		else
		{
			// update wall Z offset
			m_fWallYOffset = (-100.0f * m_fAnimatedValue[1]);
		}
		break;
		
	case 4:
		mTimer.RemoveTimer(1);
		m_iGenericState = 0;
		m_eStage1State = E_STAGE_END;
		break;
	}
}

void CWorld::renderStage1()
{
	const float hw = 225.0f / 2.0f;
	const float cw = 225.0f / 5.0f;
	unsigned int i;

	mGC->setRotation(D3DXVECTOR3(RADIAN(-90), 0.0f, 0.0f));
	mGC->setPosition(D3DXVECTOR3(0.0f, 70.0f + m_fWallYOffset, 359.5f));
	mGC->draw(E_STAGE1_GLYPHS_WALL);
	
	mGC->setRotation(D3DXVECTOR3(0.0f, 0.0f, 0.0f));

	if(m_bPressedKeys && m_uInputKey < 6)
	{
		for(i = 0; i < 6; i++)
		{
			if(m_uInputKey != i)
			{
				mGC->setPosition(D3DXVECTOR3(-hw + (i * cw), 0.1f + m_fWallYOffset, 170.0f));
				mGC->draw(E_STAGE1_GLYPH_GROUND_UP);
			}
			else
			{
				mGC->setPosition(D3DXVECTOR3(-hw + (i * cw), -1.0f + m_fWallYOffset, 170.0f));
				mGC->draw(E_STAGE1_GLYPH_GROUND_DOWN);
			}
		}
	}
	else
	{
		for(i = 0; i < 6; i++)
		{
			mGC->setPosition(D3DXVECTOR3(-hw + (i * cw), 0.1f + m_fWallYOffset, 170.0f));
			mGC->draw(E_STAGE1_GLYPH_GROUND_UP);
		}
	}
}

void CWorld::renderStage1Alpha()
{
	const float hw = 200.0f / 2.0f;
	const float cw = 200.0f / 3.0f;
	const float hw2 = 200.0f / 2.0f;
	const float cw2 = 200.0f / 3.0f;
	unsigned int i;
	D3DMATERIAL9 mtrl;

	mGC->setRotation(D3DXVECTOR3(RADIAN(-90), 0.0f, 0.0f));

	for(i = 0; i < 4; i++)
	{
		mGC->setPosition(D3DXVECTOR3(-hw2 + (i * cw2), 70.0f + m_fWallYOffset, 359.0f));
		if(i < m_uCurrentGlyph)
		{
			mGC->draw(E_STAGE1_GLYPH_1_NOGLOW + i);
		}
		else
		{
			mGC->draw(E_STAGE1_GLYPH_1_WALL + i);
		}
	}

	if(m_eStage1State == E_STAGE1_PUZZLE_START)
	{
		switch(m_iGenericState)
		{
		case 1:
			// Render glow
			mDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

			mtrl = d3d::WHITE_MTRL;
			if(m_fAnimatedValue[0] < 0.5f)
			{
				mtrl.Diffuse.a = min(m_fAnimatedValue[0] * 2.0f, 1.0f);
			}
			else
			{
				mtrl.Diffuse.a = max(1.0f - ((m_fAnimatedValue[0] - 0.5f) * 2.0f), 0.0f);
			}
			mDevice->SetMaterial(&mtrl);

			mGC->setPosition(D3DXVECTOR3(-hw + (m_uCurrentGlyph * cw), 70.0f + m_fWallYOffset, 358.5f));
			mGC->draw(E_STAGE1_GLYPH_1_GLOW + m_uCurrentGlyph);
			mDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
			break;
		}
	}
	else if(m_eStage1State == E_STAGE1_CORRECT_INPUT)
	{
		switch(m_iGenericState)
		{
		case 2:
			// Render new solved glyph
			mDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

			mtrl = d3d::WHITE_MTRL;
			mtrl.Diffuse.a = min(m_fAnimatedValue[0], 1.0f);
			mDevice->SetMaterial(&mtrl);

			mGC->setPosition(D3DXVECTOR3(-hw + (m_uCurrentGlyph * cw), 70.0f + m_fWallYOffset, 358.75f));
			mGC->draw(E_STAGE1_GLYPH_1_NOGLOW + m_uCurrentGlyph);
			mDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
			break;
		}
	}
	else if(m_eStage1State == E_STAGE1_PUZZLE_SOLVED)
	{
		switch(m_iGenericState)
		{
		case 2:
			// Render current glyph glow
			mDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

			mtrl = d3d::WHITE_MTRL;
			if(m_fAnimatedValue[0] < 0.5f)
			{
				mtrl.Diffuse.a = min(m_fAnimatedValue[0] * 2.0f, 1.0f);
			}
			else
			{
				mtrl.Diffuse.a = max(1.0f - ((m_fAnimatedValue[0] - 0.5f) * 2.0f), 0.0f);
			}
			mDevice->SetMaterial(&mtrl);

			mGC->setPosition(D3DXVECTOR3(-hw + (m_uCounter * cw), 70.0f + m_fWallYOffset, 358.5f));
			mGC->draw(E_STAGE1_GLYPH_1_GLOW + m_uCounter);
			mDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
			break;
		}
	}
}


void CWorld::createStage2()
{
	mGC->add(444, geometry::createQuad((float)WINDOWX, (float)WINDOWY));
	mGC->giveTextureTo(444, L"textures/end.png");
}

void CWorld::destroyStage2()
{
}

const StageBoundary CWorld::getStage1Boundary() const
{
	return StageBoundary(-150.0f, 150.0f, -60.0f, 340.0f);
}

void CWorld::updateStage2()
{
	D3DXVECTOR3 at = mVincent->getPosition();
	at.y = 35.0f;
	D3DXMatrixLookAtLH(&mViewMatrix, &D3DXVECTOR3(0.0f, 110.0f, -160.0f + at.z), 
			&at, &D3DXVECTOR3(0.0f, 1.0f, 0.0f));

	switch(m_eStage2State)
	{
	case E_STAGE_BEGIN:
		m_eStage2State = E_STAGE2_WAIT_FOR_INPUT;
		break;

	case E_STAGE2_WAIT_FOR_INPUT:
		stage2WaitForInput();
		break;

	case E_STAGE2_CREDITS:
		stage2Credits();
		break;

	case E_STAGE_END:
		break;
	}
}

void CWorld::stage2WaitForInput()
{
	if(m_bActionTriggered)
	{
		geometry::Rectf r(-20.0f, 840.0f, 20.0f, 760.0f);
		if(r.collisionXZ(mVincent->getPosition()))
		{
			m_eStage2State = E_STAGE2_CREDITS;
		}
	}
}

void CWorld::stage2Credits()
{
	switch(m_iGenericState)
	{
	case 0:
		mTimer.AddTimer(0, 1.0f, &m_fAnimatedValue[0]);
		m_iGenericState++;
		break;
	case 1:
		// Fade In
		if(m_fAnimatedValue[0] >= 1.0f)
		{
			mTimer.AddTimer(1, 5.0f, &m_fAnimatedValue[1]);
			mTimer.RemoveTimer(0);
			m_iGenericState++;
		}
		break;
	case 2:
		if(m_fAnimatedValue[1] >= 1.0f)
		{
			m_fAnimatedValue[1] = 1.0f;
			mTimer.RemoveTimer(1);
			m_iGenericState++;
		}
		break;
	case 3:
		break;
	}
}

void CWorld::renderStage2()
{
	mGC->setRotation(D3DXVECTOR3(0.0f, 0.0f, 0.0f));
	mGC->setPosition(D3DXVECTOR3(0.0f, 0.5f, 800));
	mGC->draw(E_STAGE1_GLYPH_GROUND_DOWN);
}

void CWorld::renderStage2Alpha()
{
}

void CWorld::renderStage2Overlay()
{
	D3DXMATRIX proj, view;
	D3DMATERIAL9 mtrl = d3d::WHITE_MTRL;

	switch(m_iGenericState)
	{
	case 1:
	case 2:
	case 3:
		D3DXMatrixOrthoLH(&proj, (float)WINDOWX, (float)WINDOWY,
			0.0f, 10.0f);
		D3DXMatrixIdentity(&view);

		mtrl.Diffuse.a = m_fAnimatedValue[1];
		
		mDevice->SetTransform(D3DTS_VIEW, &view);
		mDevice->SetTransform(D3DTS_PROJECTION, &proj);

		mDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, true);
		mDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
		
		mDevice->SetMaterial(&mtrl);
		mGC->setPosition(D3DXVECTOR3(0.0f, 0.0f, 5.0f));
		mGC->setRotation(D3DXVECTOR3(RADIAN(-90), 0.0f, 0.0f));
		mGC->draw(444);

		mDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
		mDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, false);

		break;
	}
}