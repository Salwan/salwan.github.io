/*************************************************************
 * Character Animation Article
 *
 * Title: Forward declaration of objects.
 *
 * Author: Salwan A. AlHelaly
 *
 *************************************************************/

#ifndef __FORWARD_H__
#define __FORWARD_H__

class CWorld;
class CVincent;

#endif
