﻿package  
{	
	import flash.display.MovieClip;	
	
	public class GuardRoom extends Room 
	{
		public function GuardRoom() 
		{
			// constructor code
		}
	}
	
}
