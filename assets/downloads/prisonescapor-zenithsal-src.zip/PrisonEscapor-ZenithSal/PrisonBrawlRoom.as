﻿package  
{	
	import flash.display.MovieClip;	
	
	public class PrisonBrawlRoom extends Room
	{		
		public function PrisonBrawlRoom() 
		{
			// constructor code
		}
	}
	
}
