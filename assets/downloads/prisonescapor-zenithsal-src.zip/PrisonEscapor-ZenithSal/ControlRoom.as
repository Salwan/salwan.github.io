﻿package  
{	
	import flash.display.MovieClip;
	
	public class ControlRoom extends Room
	{
		public function ControlRoom() 
		{
			// constructor code
		}
	}
	
}
