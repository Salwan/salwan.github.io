﻿package  
{
	import flash.display.MovieClip;
	
	public class FlintDrillDebris_Image extends MovieClip 
	{
		public function FlintDrillDebris_Image() 
		{
			// constructor code
		}
	}
	
}
