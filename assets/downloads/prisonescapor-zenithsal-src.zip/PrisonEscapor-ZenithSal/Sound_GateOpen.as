﻿package  {
	
	import flash.media.Sound;
	import cmg.SoundEx;
	
	public class Sound_GateOpen extends SoundEx {
		
		
		public function Sound_GateOpen() {
			// constructor code
		}
	}
	
}
