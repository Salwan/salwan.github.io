﻿package  
{	
	import flash.display.MovieClip;	
	
	public class DecOutLayer extends MovieClip 
	{
		public function DecOutLayer() 
		{
			// constructor code
		}
	}
	
}
