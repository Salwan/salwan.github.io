﻿package  
{	
	import flash.display.MovieClip;	
	
	public class NPCLayer extends MovieClip 
	{
		public function NPCLayer() 
		{
			// constructor code
		}
	}
	
}
