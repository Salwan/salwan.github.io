﻿package  
{	
	import flash.display.MovieClip;	
	
	public class LayerDepth extends MovieClip 
	{
		public function LayerDepth() 
		{
			// constructor code
		}
	}
	
}
