﻿package  
{	
	import flash.media.Sound;	
	import cmg.SoundEx;
	
	public class Sound_DrillGates extends SoundEx 
	{				
		public function Sound_DrillGates() 
		{
			// constructor code
		}
	}
	
}
