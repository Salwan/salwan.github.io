﻿package  
{	
	import flash.display.MovieClip;	
	
	public class Level4 extends Level
	{
		public function Level4() 
		{
			// constructor code
		}
	}
	
}
