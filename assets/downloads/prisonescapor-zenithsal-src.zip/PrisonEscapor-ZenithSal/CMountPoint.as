﻿package  
{	
	import flash.display.MovieClip;	
	import cmg.*;
	import flash.geom.Point;
	
	public class CMountPoint extends MovieClipEx
	{
		public function CMountPoint() 
		{
			visible = false;
		}
	}
	
}
