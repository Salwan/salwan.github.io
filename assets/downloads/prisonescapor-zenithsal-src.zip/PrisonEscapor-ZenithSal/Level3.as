﻿package  
{	
	import flash.display.MovieClip;	
	
	public class Level3 extends Level 
	{
		public function Level3() {
			// constructor code
		}
	}
	
}
