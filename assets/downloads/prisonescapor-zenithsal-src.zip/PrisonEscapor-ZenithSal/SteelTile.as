﻿package  {
	
	import flash.display.MovieClip;
	
	
	public class SteelTile extends TunnelTile 
	{
		public function SteelTile() 
		{
			// constructor code
		}
	}
	
}
