﻿package  
{	
	import flash.display.MovieClip;	
	
	public class BeatingStars extends MovieClip 
	{
		public function BeatingStars() 
		{
			// constructor code
		}
	}
	
}
