﻿package  
{	
	import flash.media.Sound;	
	import cmg.SoundEx;
	
	public class Sound_DrillSteel extends SoundEx
	{
		public function Sound_DrillSteel() 
		{
			// constructor code
		}
	}
	
}
