﻿package  
{	
	import flash.display.MovieClip;	
	
	public class DiggingTool extends MovieClip 
	{
		public function DiggingTool() 
		{
			// constructor code
		}
	}
	
}
