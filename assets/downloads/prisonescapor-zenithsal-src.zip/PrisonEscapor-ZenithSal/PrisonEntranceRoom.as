﻿package  
{	
	import flash.display.MovieClip;	
	
	public class PrisonEntranceRoom extends Room 
	{
		public function PrisonEntranceRoom() 
		{
			// constructor code
		}
	}
	
}
