﻿package  {
	
	import flash.media.Sound;
	import cmg.SoundEx;
	
	public class Sound_TerminalExplode extends SoundEx {
		
		
		public function Sound_TerminalExplode() {
			// constructor code
		}
	}
	
}
