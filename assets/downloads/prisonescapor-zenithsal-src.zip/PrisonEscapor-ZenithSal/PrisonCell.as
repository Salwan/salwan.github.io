﻿package  
{	
	import flash.display.MovieClip;
		
	public class PrisonCell extends Room
	{
		public function PrisonCell() 
		{
			// constructor code
		}
	}
	
}
