/*
 * FLINT PARTICLE SYSTEM
 * .....................
 * 
 * Author: Richard Lord
 * Copyright (c) Richard Lord 2008-2011
 * http://flintparticles.org
 * 
 * 
 * Licence Agreement
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package cmg.flintparticles.threeD.actions 
{
	import cmg.flintparticles.common.actions.ActionBase;
	import cmg.flintparticles.common.emitters.Emitter;
	import cmg.flintparticles.common.particles.Particle;
	import cmg.flintparticles.threeD.particles.Particle3D;

	import flash.geom.Vector3D;

	/**
	 * The Move action updates the position of the particle based on its velocity.
	 * It uses a Euler integrator to calculate the new position, hence the name.
	 * 
	 * <p>This action has a priority of -10, so that it executes after other actions.</p>
	 */
	public class Move extends ActionBase
	{
		/**
		 * The constructor creates a Move action for use by 
		 * an emitter. To add a Move to all particles created by an emitter, use the
		 * emitter's addAction method.
		 * 
		 * @see cmg.flintparticles.common.emitters.Emitter#addAction()
		 */
		public function Move()
		{
			priority = -10;
		}

		/**
		 * @inheritDoc
		 */
		override public function update( emitter:Emitter, particle:Particle, time:Number ):void
		{
			var p:Vector3D = Particle3D( particle ).position;
			var v:Vector3D = Particle3D( particle ).velocity;
			p.x += v.x * time;
			p.y += v.y * time;
			p.z += v.z * time;
		}
	}
}
