package cmg 
{
	/**
	 * ...
	 * @author ZenithSal
	 */
	public class Reference 
	{
		public var value:*;
		
		public function Reference() 
		{			
		}
		
	}

}