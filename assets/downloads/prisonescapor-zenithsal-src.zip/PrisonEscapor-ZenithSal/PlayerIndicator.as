﻿package  
{	
	import flash.display.MovieClip;	
	
	public class PlayerIndicator extends MovieClip 
	{
		public function PlayerIndicator() 
		{			
			// constructor code
		}
	}
	
}
