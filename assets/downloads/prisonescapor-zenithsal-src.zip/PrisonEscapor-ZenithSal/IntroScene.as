﻿package  
{	
	import flash.display.MovieClip;		
	import flash.events.Event;
	
	public class IntroScene extends MovieClip 
	{
		public function IntroScene() 
		{
			addEventListener(Event.ADDED_TO_STAGE, onAddedToStage, false, 0, true);
		}
		
		protected function onAddedToStage(e:Event):void
		{
		}
	}
	
}
