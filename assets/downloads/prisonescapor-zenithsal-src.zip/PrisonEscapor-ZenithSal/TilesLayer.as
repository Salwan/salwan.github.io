﻿package  {
	
	import flash.display.MovieClip;
	import cmg.World;
	
	public class TilesLayer extends MovieClip {
		
		
		public function TilesLayer() {
			World.layers["tiles"] = this;
		}
	}
	
}
