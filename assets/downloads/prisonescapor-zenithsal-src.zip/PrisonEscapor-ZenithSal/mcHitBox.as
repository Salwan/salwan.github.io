﻿package  
{	
	import flash.display.MovieClip;	
	
	public class mcHitBox extends MovieClip 
	{
		public function mcHitBox() 
		{
			visible = false;
		}
	}
	
}
