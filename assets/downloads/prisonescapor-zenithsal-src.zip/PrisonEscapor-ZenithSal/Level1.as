package  
{
	/**
	 * ...
	 * @author ZenithSal
	 */
	public class Level1 extends Level
	{
		
		public function Level1() 
		{
			
		}
		
	}

}