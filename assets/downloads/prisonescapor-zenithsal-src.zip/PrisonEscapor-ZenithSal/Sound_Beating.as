﻿package  
{	
	import flash.media.Sound;
	import cmg.SoundEx;
	
	public class Sound_Beating extends SoundEx
	{
		public function Sound_Beating() 
		{
			// constructor code
		}
	}
	
}
