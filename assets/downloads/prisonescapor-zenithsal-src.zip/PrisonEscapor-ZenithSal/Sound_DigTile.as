﻿package  
{	
	import cmg.SoundEx;
	import flash.media.Sound;	
	
	public class Sound_DigTile extends SoundEx
	{
		public function Sound_DigTile() 
		{
			// constructor code
		}
	}
	
}
