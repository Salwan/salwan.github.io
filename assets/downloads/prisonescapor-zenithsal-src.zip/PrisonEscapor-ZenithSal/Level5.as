﻿package  
{	
	import flash.display.MovieClip;	
	
	public class Level5 extends Level
	{
		public function Level5() 
		{
			// constructor code
		}
	}
	
}
