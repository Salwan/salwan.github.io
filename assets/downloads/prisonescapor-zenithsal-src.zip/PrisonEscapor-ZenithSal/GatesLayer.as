﻿package  
{	
	import flash.display.MovieClip;	
	
	public class GatesLayer extends MovieClip 
	{
		public function GatesLayer() 
		{
			// constructor code
		}
	}
	
}
